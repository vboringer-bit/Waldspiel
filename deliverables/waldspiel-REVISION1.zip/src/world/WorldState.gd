class_name WorldState
extends RefCounted
## PHASE 2: Laufzeit-Zustand der ENDlichen Wasserreservoirs.
## Wo Reservoirs liegen, bestimmt ausschliesslich der Seed (WorldGenerator).
## WIE VIEL noch uebrig ist, ist Spielzustand und gehoert daher ins Savegame,
## nicht in den Generator. Sonst wuerde ein neu geladener Chunk nachfuellen.
## Kein Node, kein Autoload: ChunkManager besitzt die Instanz und gibt sie
## an WaterSystem / InteractionController / SaveManager / HUD weiter.

var generator: WorldGenerator

var _remaining: Dictionary = {}   # "gx:ty" -> float
var _dry: Dictionary = {}         # "gx:ty" -> true


func setup(p_generator: WorldGenerator) -> void:
	generator = p_generator
	reset()


func reset() -> void:
	_remaining.clear()
	_dry.clear()


static func key(global_tile_x: int, tile_y: int) -> String:
	return "%d:%d" % [global_tile_x, tile_y]


func remaining_at(global_tile_x: int, tile_y: int) -> float:
	var k := key(global_tile_x, tile_y)
	if _dry.has(k):
		return 0.0
	if _remaining.has(k):
		return float(_remaining[k])
	return generator.reservoir_capacity_at(global_tile_x, tile_y)


func is_dry(global_tile_x: int, tile_y: int) -> bool:
	return _dry.has(key(global_tile_x, tile_y))


func is_reservoir(global_tile_x: int, tile_y: int) -> bool:
	return generator.reservoir_at(global_tile_x, tile_y)


## Entnimmt Wasser; liefert die tatsaechlich entnommene Menge zurueck.
## Beim Uebergang auf 0 wird das Tile optisch umgeschaltet (EventBus).
func consume(global_tile_x: int, tile_y: int, amount: float) -> float:
	if amount <= 0.0 or not is_reservoir(global_tile_x, tile_y):
		return 0.0
	var k := key(global_tile_x, tile_y)
	if _dry.has(k):
		return 0.0
	var rem := remaining_at(global_tile_x, tile_y)
	var taken := minf(amount, rem)
	rem -= taken
	_remaining[k] = rem
	if rem <= 0.001:
		_dry[k] = true
		EventBus.reservoir_dried.emit(Vector2i(global_tile_x, tile_y))
		EventBus.toast.emit(tr("MSG_RESERVOIR_DRY"))
	else:
		EventBus.reservoir_consumed.emit(Vector2i(global_tile_x, tile_y), rem)
	return taken


func dry_count() -> int:
	return _dry.size()


## Fuer Screenshots / Tests: ein Reservoir direkt leer machen.
func debug_drain(global_tile_x: int, tile_y: int) -> void:
	if is_reservoir(global_tile_x, tile_y):
		consume(global_tile_x, tile_y, 1.0e9)


# --------------------------------------------------------------------------- #
# Save / Load
# --------------------------------------------------------------------------- #
func to_dict() -> Dictionary:
	var dry: Array = []
	for k in _dry.keys():
		var parts := String(k).split(":")
		dry.append([int(parts[0]), int(parts[1])])
	var rem: Dictionary = {}
	for k in _remaining.keys():
		rem[String(k)] = float(_remaining[k])
	return {"dry": dry, "remaining": rem}


func from_dict(d: Dictionary) -> void:
	reset()
	for pair in d.get("dry", []):
		if pair is Array and pair.size() >= 2:
			_dry[key(int(pair[0]), int(pair[1]))] = true
	var rem: Dictionary = d.get("remaining", {})
	for k in rem.keys():
		_remaining[String(k)] = float(rem[k])
