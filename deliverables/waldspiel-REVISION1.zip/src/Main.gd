extends Node2D
## Einstiegsszene. Verdrahtet die modularen Systeme; enthaelt selbst keine
## Spiellogik. PHASE 0 (Welt/Kamera), PHASE 1 (Kern-Loop) und PHASE 2
## (Wachstum & Boden) laufen hier zusammen.

@onready var _sky: SkyBackground = $SkyBackground
@onready var _mountains: MountainBackdrop = $World/MountainBackdrop
@onready var _chunk_manager: ChunkManager = $World/ChunkManager
@onready var _camera: CameraController = $World/WorldCamera
@onready var _trees: Node2D = $World/Trees
@onready var _bird_layer: BirdEvent = $World/BirdLayer
@onready var _ghost: GhostPreview = $World/GhostPreview
@onready var _growth: GrowthSystem = $Systems/GrowthSystem
@onready var _water: WaterSystem = $Systems/WaterSystem
@onready var _time: TimeManager = $Systems/TimeManager
@onready var _save: SaveManager = $Systems/SaveManager
@onready var _interaction: InteractionController = $Interaction
@onready var _hud: HUD = $HUD

var _last_fit: Vector2i = Vector2i.ZERO


func _ready() -> void:
	var args := OS.get_cmdline_args() + OS.get_cmdline_user_args()
	# Fuer Tests/Screenshots: trotz Vollbild-Default in den Fenstermodus.
	if args.has("--windowed"):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	_fit_display()
	get_tree().root.size_changed.connect(_fit_display)
	_chunk_manager.setup(_camera)
	_mountains.setup(_camera)
	_sky.refresh_layout()
	var state := _chunk_manager.world_state
	_growth.setup(_chunk_manager.generator)
	_water.setup(state, _chunk_manager.generator)
	_interaction.setup(_camera, _chunk_manager, _trees, _bird_layer,
		_water, _growth, state, _ghost)
	_save.setup(_interaction, _chunk_manager, state)
	_hud.setup(_interaction, _growth, _water, _time, _save, state)
	_apply_presets(args)

	# Headless-Tests (kein Addon):
	#   godot --headless --path . -- --phase0-smoke
	#   godot --headless --path . -- --phase1-smoke
	#   godot --headless --path . -- --phase2-smoke
	if args.has("--phase0-smoke"):
		var smoke0 = preload("res://tests/Phase0Smoke.gd").new()
		smoke0.setup(_chunk_manager, _camera)
		add_child(smoke0)
	elif args.has("--phase1-smoke"):
		var smoke1 = preload("res://tests/Phase1Smoke.gd").new()
		smoke1.setup(_interaction, _growth, _water, _save, _chunk_manager, _camera)
		add_child(smoke1)
	elif args.has("--phase2-smoke"):
		var smoke2 = preload("res://tests/Phase2Smoke.gd").new()
		smoke2.setup(_interaction, _growth, _water, _save,
			_chunk_manager, _camera, state, _ghost)
		add_child(smoke2)
	elif args.has("--rev1-smoke"):
		var smoke_r = preload("res://tests/Revision1Smoke.gd").new()
		smoke_r.setup(_interaction, _save, _chunk_manager, _camera)
		add_child(smoke_r)

	print("[Main] PHASE 2 + REVISION 1 bereit: %d Eicheln, Vollbild-Skalierung, fliessende Oberflaeche, organische Strukturen." % [
		_interaction.get_seed_count()])


## Gleichmaessig auf die Fensterflaeche skalieren. Mit aspect="expand" wird
## der Viewport dadurch groesser als 1920x1080 statt von grauen Raendern
## umgeben zu sein; alle Canvas-Inhalte werden mit dem Faktor mitvergroessert.
func _fit_display() -> void:
	var ws := DisplayServer.window_get_size()
	if ws.x <= 0 or ws.y <= 0 or ws == _last_fit:
		return
	_last_fit = ws
	var f := minf(float(ws.x) / 1920.0, float(ws.y) / 1080.0)
	get_tree().root.content_scale_factor = clampf(f, 0.25, 4.0)


## F11 = Vollbild an/aus. Dank _fit_display() skaliert der
## 1920x1080-Viewport dabei auf den Monitor (kein grauer Rand mehr).
func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return
	var key := event as InputEventKey
	if not key.pressed or key.echo or key.keycode != KEY_F11:
		return
	var mode := DisplayServer.window_get_mode()
	if mode == DisplayServer.WINDOW_MODE_FULLSCREEN \
			or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	get_viewport().set_input_as_handled()


## Reproduzierbare Zustaende fuer Screenshots / Tests.
## Ohne Argument: F5 startet mit 2 Eicheln und zufaelligem Seed.
func _apply_presets(args: PackedStringArray) -> void:
	if args.has("--rev1-shot-surface"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 300.0))
	elif args.has("--rev1-shot-carry"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 330.0))
		_interaction.debug_carry_at(Vector2(960.0, 430.0), 320.0)
	elif args.has("--rev1-shot-placed"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 330.0))
		_interaction.debug_carry_at(Vector2(960.0, 430.0), 320.0)
		_interaction.debug_place_carried_at(320.0)
	elif args.has("--phase2-shot-caves"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 700.0))
	elif args.has("--phase2-shot-roots"):
		_camera.set_zoom_immediate(1.25)
		_camera.teleport_to(Vector2(0.0, 490.0))
		_interaction.debug_plant_twice()
		_interaction.debug_grow_roots(14)
		_water.set_process(false)
	elif args.has("--phase2-shot-manual"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 390.0))
		_interaction.debug_plant_twice()
		Global.auto_mode = false
		_growth.set_process(false)
		_interaction.debug_grow_roots(3)
		_interaction.selected_tree.glucose = 42.0
		_interaction.debug_show_ghost()
		_hud.refresh_texts()
		_hud.refresh()
	elif args.has("--phase2-shot-dry"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 700.0))
		_interaction.debug_drain_reservoirs()
	elif args.has("--phase1-shot-bird"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_first_seed()
	elif args.has("--phase1-shot-planted"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_plant_twice()
		_growth.debug_advance(5.0)
	elif args.has("--phase1-shot-rain"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_plant_twice()
		_growth.debug_advance(2.0)
		_water.force_rain(30.0)
	elif args.has("--phase0-shot-soil"):
		_camera.set_zoom_immediate(0.85)
		_camera.teleport_to(Vector2(0.0, 790.0))
	elif args.has("--phase0-shot-pan"):
		_camera.set_zoom_immediate(0.75)
		_camera.teleport_to(Vector2(4300.0, 500.0))
