# Wald-Regeneration — PHASE 2 + REVISION 1

> 2D-Seitenansicht (Himmel **und** Bodenquerschnitt) · Godot **4.7.2 stable** · GDScript · Forward+ / Vulkan
> Inspiriert von Mycelium / Mycelarium. Nach dem Waldbrand: 2 Eicheln, ein hungriger Vogel, ein Keimling mit wachsender Pfahlwurzel.

**Status:** PHASE 0 ✅ · PHASE 1 ✅ · PHASE 2 ✅ · **REVISION 1 ✅ (4 Korrekturen, getestet)** · **PHASE 3 wurde nicht begonnen.**

**Am Ende jeder abgeschlossenen Runde gibt es zusätzlich eine komplette ZIP** → `waldspiel-REVISION1.zip`.

---

## Starten

1. Godot 4.7.2 stable öffnen → `project.godot` importieren (oder die ZIP entpacken und `GODOT-IMPORT.txt` folgen).
2. **F5**. Das Spiel startet **direkt im Vollbild** und skaliert sich auf die Monitorfläche – keine grauen Ränder mehr. **F11** schaltet Vollbild/Fenster um; `--windowed` ist ein Start-Argument für Tests.
3. Der **Welt-Seed wird bei jedem Neustart neu gewürfelt**. Für eine reproduzierbare Welt: `--seed=20261105` oder **Laden** (Seed steht im Savegame).

## Steuerung

| Eingabe | Wirkung |
|---|---|
| **Linksklick auf das Eichel-Icon (HUD) oder freien Boden** | Eichel **aufnehmen**: sie schwebt ab jetzt an der Maus |
| **Linksklick, während die Eichel schwebt** | Eichel **überall auf der Oberfläche platzieren** (X-Position der Maus, sanft auf die Geländelinie gesetzt) |
| Rechtsklick / `Esc` beim Tragen | Eichel zurück ins Inventar legen (kein Verbrauch, kein Vogel) |
| MANUELL: Linksklick auf ein Wurzel-Segment | Wurzel wächst in Erd-Richtung; Kosten nach Boden (Ghost-Preview zeigt Ziel + Preis) |
| MANUELL: Linksklick auf Baumkrone | Blatt wachsen (10 Glucose) |
| AUTO | Baum verteilt Glucose selbst (Wurzeln bei Durst, sonst Blätter) |
| Rechtsklick (ohne getragene Eichel) | Info (Baumwerte oder Bodenmaterial / Tiefe / Wurzel-Kosten / Seed) |
| `W A S D` / Maus am Rand | Kamera schwenken |
| Mausrad | Zoom `0.5x … 2.0x`, weich interpoliert |
| `R` | Regen sofort auslösen (Dev-Hook; echtes Intervall 2–5 Min) |
| `F11` | Vollbild an/aus |
| HUD | AUTO/MANUELL, DE/EN, Speichern, Laden |

**Vogel-Timing:** Die **erste platzierte** Eichel wird weiterhin vom Vogel geklaut – aber **erst nach dem Platzierungsversuch**, nicht schon beim Aufnehmen. Danach keimt die zweite Eichel.

Skilltree-Button = deaktivierter Platzhalter (PHASE 4). Zeit „Jahr 1 · Frühling" = Platzhalter (PHASE 3). Kein Tag/Nacht.

## REVISION 1 – die vier Korrekturen

1. **Vollbild füllt den Monitor.** `project.godot` startet mit `window/size/mode=3` (Fullscreen). `window/stretch/aspect="expand"` plus `Main._fit_display()` setzen `content_scale_factor = min(Breite/1920, Höhe/1080)` und aktualisieren ihn bei jeder Fensteränderung. Ergebnis: gleichmäßige Vergrößerung auf 16:9, 16:10 und Ultrawide – kein „gleiche Größe + grau drumherum". Verifiziert mit Xvfb-Root-Screenshots bei **2560×1440** und **3440×1440** (Grau-Anteil < 0,02 %).
2. **Organischere Untergrund-Strukturen.** `WorldGenerator._blob_field()` legt pro Zelle 1–3 **rotierte Ellipsen** mit stark variierenden Radien und Jitter über Zellgrenzen hinaus an; eine `FastNoiseLite`-Kante verformt den Rand. Drei überlagerte Familien (große Kammern, kleine Taschen, lange Gänge) erzeugen unregelmäßige, aber **zusammenhängende** Blobs – kein Raster aus gleichen Kreisen, kein 1-Tile-Rauschen. Das Starter-Reservoir hat nur noch einen garantierten 3×3-Kern plus zerfranste Noise-Linse.
3. **Fließende Oberfläche.** `height_smooth_at()` liefert eine kontinuierliche Hügellinie; `TerrainSurface.gd` zeichnet daraus die sichtbare Aschekante in **4px-Schritten** (max. Sprung 4 px statt 16 px). Die oberste TileMapLayer-Zeile wird deshalb ausgelassen und durch dieses Profil ersetzt; Schichtgrenzen (`depth_px_at`) und Baum-/Wurzel-Ursprung folgen ebenfalls der weichen Linie. Spiellogik, Kollision und Save/Load bleiben auf dem 16px-Raster.
4. **Eichel-Schwebe & freie Platzierung.** Neuer Zustand in `InteractionController`: `pick_up_acorn()` → Sprite auf `CarryLayer` (folgt der Maus, leichtes Schweben) + halbtransparente Platzierungs-Vorschau auf der Oberfläche → `_place_carried()` → **danach** `plant_seed_at()` mit Vogel-Event. Abbruch per Rechtsklick/`Esc`, Save/Load erhält die getragene Eichel.

## Was PHASE 2 simuliert (unverändert gültig)

- **Echte Wurzeln:** `Tree -> Roots -> RootSegment -> RootTip`, 16px-Raster, max. 32 Segmente. Eiche = Pfahlwurzel + Herzwurzelsystem (alle 4 Tiefen-Tiles eine Seitenwurzel als weiterer anklickbarer Tip).
- **Bodenhärte:** `GrowthCost` – Asche 8, Humus 9, **Mutterboden 10**, Lehm 13, Fels 25, Stein 30, Reservoir 15, Höhle 4 Glucose. AUTO und MANUELL zahlen identisch.
- **Ghost-Preview:** bei Mausbewegung im MANUELL-Modus grüner Rahmen + transparentes Wurzel-Sprite + Preis; rot bei zu wenig Glucose.
- **Wasserreservoirs:** `2.0/s` pro berührtem Tile statt `0.1/s`, Kapazität 60–120 Einheiten, **trocknen aus** und werden optisch heller (`SLOT_DRY_WATER`). Zustand bleibt über Chunk-Wechsel und Save/Load erhalten.
- **Speichern v2:** Wurzel-Segmente + Reservoir-Zustand + getragene Eichel; liest auch PHASE-1-Spielstände (v1).

## Ordnerstruktur

```
waldspiel/
├── project.godot                    # Godot 4.7.2, Forward+, Fullscreen, Nearest
├── GODOT-IMPORT.txt                 # Import-Anleitung (liegt auch in der ZIP)
├── DECISIONS.md                     # alle Annahmen (PHASE 0/1/2 + REVISION 1)
├── README.md
├── PHASE0/1/2-ERGEBNIS.md + .html   # historische Ergebnisberichte
├── REVISION1-ERGEBNIS.md + .html    # Bericht dieser Korrekturrunde
├── tools/
│   ├── generate_placeholders.py     # erzeugt alle 18 PNGs neu (17 Atlas-Slots)
│   ├── build_phase0_report.py / build_phase1_report.py / build_phase2_report.py
│   ├── build_revision1_report.py
│   └── build_zip.py                 # vollständige Godot-ZIP
├── assets/placeholders/             # Boden-Atlas, Sprites, Icons, Himmel/Berge
├── data/localization.csv            # Key, DE, EN (alle Phasen)
├── data/species/oak.tres
├── src/
│   ├── Main.gd / Main.tscn           # _fit_display(), F11, CarryLayer, Presets
│   ├── autoload/                    # Global (Zufallsseed), EventBus
│   ├── world/                       # WorldGenerator, TerrainSurface, TerrainAtlas,
│   │                                # Chunk, ChunkManager, WorldState
│   ├── camera/, background/, plants/, systems/, ui/
├── tests/                           # Phase0/1/2Smoke.gd + Revision1Smoke.gd
└── screenshots/                     # phase0/1/2_*.png + rev1_*.png
```

## Tests

```bash
godot --headless --path . --import
godot --headless --path . --quit-after 180        # F5-Ersatz
godot --headless --path . -- --phase0-smoke       # Regression: OK
godot --headless --path . -- --phase1-smoke       # Regression: OK (25 Checks)
godot --headless --path . -- --phase2-smoke       # Regression: OK (24 Checks)
godot --headless --path . -- --rev1-smoke         # REVISION 1: 31 Checks, OK
```

`--rev1-smoke` prüft u. a. Fullscreen-Settings & Skalierungsfaktor, **0 Ecken ≥ 16 px** (max. Sprung 4 px), zusammenhängende Blobs mit ≥ 3 Komponenten/Größen, Seed-Varianz, organisches Starter-Reservoir, „Vogel erst nach Platzierung", freie Platzierung bei x=320 und x=−640, Save/Load mit schwebender Eichel und alle P0–P2-Regressionen. Erwartung: `[SMOKE] Ergebnis: OK`, **keine roten Fehler**.

Reproduzierbare Screenshots (Godot + Xvfb):

```bash
--seed=20261105 --rev1-shot-surface      # fließende Oberfläche + organische Höhlen
--seed=20261105 --rev1-shot-carry        # schwebende Eichel + Vorschau
--seed=20261105 --rev1-shot-placed       # Vogel NACH der Platzierung
--seed=20261105 --phase2-shot-caves / -roots / -manual / -dry
--windowed                               # Tests trotz Fullscreen-Default
```

## ZIP (vollständig, Godot-importierbar)

```bash
python3 tools/build_zip.py REVISION1   # -> /home/user/waldspiel-REVISION1.zip
```

`project.godot` liegt im **ZIP-Root**, `.godot/`-Cache und generierte `.translation` sind ausgeschlossen; alle Quellen, Assets, `.import`/`.uid`, Tests, Berichte und Screenshots sind drin. CRC-Test ist Teil des Skripts.

## Berichte / Platzhalter neu erzeugen

```bash
python3 tools/generate_placeholders.py
python3 tools/build_revision1_report.py
python3 tools/build_zip.py REVISION1
```

Details und Begründungen: **[DECISIONS.md](DECISIONS.md)** · Aktuelles Ergebnis: **[REVISION1-ERGEBNIS.md](REVISION1-ERGEBNIS.md)** / **[REVISION1-ERGEBNIS.html](REVISION1-ERGEBNIS.html)**.
