# Wald-Regeneration — PHASE 3 (Zeit & Reproduktion)

> 2D-Seitenansicht (Himmel **und** Bodenquerschnitt) · Godot **4.7.2 stable** · GDScript · Forward+ / Vulkan
> Inspiriert von Mycelium / Mycelarium. Nach dem Waldbrand: 2 Eicheln, ein hungriger Vogel, ein Keimling mit wachsender Pfahlwurzel — und jetzt Jahreszeiten, Zeitspulen und natürliche Vermehrung.

**Status:** PHASE 0 ✅ · PHASE 1 ✅ · PHASE 2 ✅ · REVISION 1 ✅ · REVISION 2 ✅ · **PHASE 3 ✅ (abgeschlossen, getestet)** · PHASE 4 ⏳ (Skilltree-UI)

**Am Ende dieser Runde gibt es wieder eine komplette ZIP** → `waldspiel-PHASE3.zip` (ersetzt `waldspiel-REVISION2.zip`). Dazu `PHASE3-ERGEBNIS.md` / `.html` mit Screenshots und Code-Snippets.

---

## Starten

1. Godot 4.7.2 stable öffnen → `project.godot` importieren (oder ZIP entpacken und `GODOT-IMPORT.txt` folgen).
2. **F5**. Ein **Startmenü** fragt vor dem Start den Schwierigkeitsgrad ab: **LEICHT / NORMAL / SCHWER**. Es blockiert nichts — man kann jederzeit im HUD umschalten.
3. Das Spiel startet **direkt im Vollbild** und skaliert auf die Monitorfläche ohne graue Ränder. **F11** schaltet um; `--windowed` ist ein Start-Argument für Tests.
4. Der **Welt-Seed wird bei jedem Neustart neu gewürfelt**. Reproduzierbar: `--seed=20261105`, `--difficulty=leicht|normal|schwer` oder **Laden**.

## Steuerung

| Eingabe | Wirkung |
|---|---|
| **Linksklick auf Eichel-Icon (HUD) oder freien Boden** | Eichel **aufnehmen** (schwebt an der Maus) |
| **Linksklick beim Tragen** | Eichel überall auf der Oberfläche platzieren |
| **Linksklick auf eine frei liegende Eichel / kleinen Hügel** | **PHASE 3:** Eichel einsammeln (Hügel erst, wenn eine Wurzel in Reichweite ist) |
| Rechtsklick / `Esc` beim Tragen | zurück ins Inventar (kein Verbrauch, kein Vogel) |
| MANUELL: Linksklick Wurzel / Krone | Wurzel bzw. Blatt wachsen; Kosten nach Boden (Ghost-Preview) |
| AUTO | Baum verteilt Glucose selbst |
| Rechtsklick (ohne getragene Eichel) | Info: Baumwerte / Bodenmaterial / Tiefe / Kosten / vergrabener Samen |
| `W A S D` / Maus am Rand | Kamera schwenken |
| Mausrad | Zoom `0.5x … 2.0x` |
| `R` | Regen sofort auslösen (Dev-Hook) |
| **Leertaste** | **PHASE 3:** Pause an/aus (auch HUD-Button) |
| **HUD `x1 / x3 / x10`** | **PHASE 3:** Zeitspulen; alle Simulationen nutzen `delta * time_scale` |
| **HUD „Schwierigkeit: …“** | **PHASE 3:** LEICHT → NORMAL → SCHWER → LEICHT |
| `F11` | Vollbild an/aus |
| HUD | AUTO/MANUELL, DE/EN, Speichern, Laden |

**Vogel-Timing:** Die **erste platzierte** Eichel wird weiterhin vom Vogel geklaut — aber erst **nach** dem Platzierungsversuch. **PHASE-3-Korrektur:** er fliegt jetzt kamera-/viewport-abhängig **bis hinter den linken Bildrand**, statt mitten in der Luft zu verschwinden. Danach keimt die zweite Eichel.

---

## Die zwei Korrekturen VOR PHASE 3

1. **Wasserreservoirs füllen sich bei Regen wieder auf.** Vorher war `WorldState.refill()` mit `1.2 * delta` für ein großes Becken praktisch unsichtbar und lief vor/neben der Wurzelentnahme. Jetzt gilt `RAIN_REFILL_PER_TILE = 0.9`, skaliert mit der **Becken-Tile-Zahl** und dem Schwierigkeitsfaktor `rain_refill`; `WaterSystem` ruft das Auffüllen **nach** `consume()` auf, mit `TimeManager.scaled_delta()`. Bei 114 Tiles sind das ~102 Einheiten/s statt vorher 1.2/s — im Smoke 20 % → 40 % in 20 simulierten Sekunden, Pegelzeile 34 → 32. Dazu Toast `MSG_RAIN_REFILL` und HUD-Text „Es regnet".
2. **Vogel fliegt aus dem Bild.** `BirdEvent` berechnet `exit_world_x()` aus Kameraposition, Viewport-Breite und Zoom, startet rechts außerhalb und bewegt den Sprite **pro Frame** mit `FLY_SPEED = 900` bis `x < screen_left - 240`. Erst dann `queue_free()`. Dauer `clamp(dist/900, 1.3, 3.4)` s. Screenshots `phase3_bird_mid.png` (mitten im Flug) und `phase3_bird_exit.png` (am linken Rand) belegen es.

---

## Was PHASE 3 simuliert

### Zeit (`src/systems/TimeManager.gd`)

- **1 Spiel-Jahr = 900 s = 15 Echtzeit-Minuten** (`year_length_seconds`, konfigurierbar), 4 Jahreszeiten à 225 s. **Kein Tag/Nacht-Zyklus** (User-Wunsch).
- Frühling: Wachstum ×1.35, Sonne ×1.25 · Sommer: ×1.00 / ×1.00 · Herbst: ×0.80 / ×0.70, Laub verfärbt sich, Eicheln fallen · **Winter: ×0.00 / ×0.00**, Laubbäume kahl, Wachstum und Fotosynthese blockiert.
- `scaled_delta(delta)` ist die **einzige** Zeitquelle für `GrowthSystem`, `WaterSystem`, `SeasonSystem` und `Tree.age`; Regen-Partikel/Tweens bleiben bewusst in Echtzeit.
- `x1 / x3 / x10` + **Pause (Leertaste)**; `scaled_delta()` liefert bei Pause `0.0`. HUD zeigt `Jahr N · Jahreszeit · xN` und einen Saison-Fortschrittsbalken.

### Samen & natürliche Vermehrung (`src/systems/SeasonSystem.gd`)

- `WorldGenerator.ground_seeds_for_chunk()` verteilt Kandidaten **per Noise** und seed-deterministisch. `SeasonSystem` erzeugt daraus Sprites: frei liegende Eicheln (`acorn.png`) und **flach vergrabene** Eicheln (`seed_mound.png`, `ty = surface_tile_y_at + 2`) — nur mit einer Wurzel in Reichweite erreichbar.
- Linksklick sammelt ein (`EventBus.seed_found` / `seed_collected`), Rechtsklick auf einen Hügel gibt den Hinweis. Bereits gesammelte IDs werden gemerkt und in **Savegame v4** gespeichert, damit sie nach Chunk-Reload nicht wieder auftauchen.
- **Herbst:** alle 12 simulierten Sekunden Eichelfall unter der Krone (Tween-Fall auf `height_smooth_at()`), max. 14 pro Herbst. Reife ab **~3 Spiel-Jahren** (`MATURE_AGE_YEARS = 3.0`); junge Bäume werfen seltener ab. Manche Eicheln keimen, wenn `sunlight > 0.4` und nicht Winter (Basis 22 %, × Schwierigkeit × reservierter Skill „Verbreitung"). Sonst bleiben sie liegen.
- Der Skill **„Verbreitung"** ist als `spread_bonus` / `set_spread_bonus()` vorbereitet; die **Skilltree-UI bleibt PHASE 4**.

### Schwierigkeitsgrade (`src/autoload/Global.gd`, `src/ui/StartMenu.gd`)

| | LEICHT | NORMAL | SCHWER |
|---|---|---|---|
| Fotosynthese / Bodenwasser | ×1.50 / ×2.00 | ×1.00 / ×1.00 | ×0.70 / ×0.60 |
| Regen-Boost / Regen-Auffüllung | ×1.20 / ×1.30 | 1.00 | ×0.80 / ×0.80 |
| Wachstumskosten / Wasserverbrauch | ×0.80 / ×0.70 | 1.00 | ×1.35 / ×1.40 |
| Eichel-Chance / Keimung / Samendichte | ×1.50 / ×1.40 / ×1.45 | 1.00 | ×0.60 / ×0.60 / ×0.70 |
| Katastrophen-Rate (vorbereitet) | 0.00 | 0.35 | 2.00 |
| Boden-Komplexität (vorbereitet) | 0.00 | 0.50 | 1.00 |
| Schalter | keine Katastrophen, kein pH | seltene Stürme/Parasiten | pH, N-P-K, Mykorrhiza, häufige Katastrophen |

> **Bewusste Grenze:** pH-Wert, Nährstoffe (N/P/K), Mykorrhiza-Netz und Dürre/Sturm/Borkenkäfer sind laut Master-Punkt 4.2 Teil der *„vollen Simulation"*. PHASE 3 legt dafür **alle Schalter und Faktoren** in `Global.difficulty_toggle()` / `difficulty_factor()` an und speichert die Wahl; die eigentliche Simulation folgt in **PHASE 5**, weil sie Systeme voraussetzt, die es im MVP noch nicht gibt. Das ist in `DECISIONS.md` §52 dokumentiert und wird in `--p3-smoke` geprüft.

### Speichern (`src/systems/SaveManager.gd`, Format **v4**)

Zusätzlich zu Wurzeln, Becken-Volumina und getragener Eichel: `difficulty`, `time` (`year`, `season`, `total_elapsed`, `season_elapsed`, `time_scale`, `paused`) und `seeds` (verbleibende + gesammelte IDs). **v3/v2/v1-Saves bleiben lesbar** und bekommen NORMAL/Frühling/Jahr 1 als Defaults.

### HUD / Vollbild-Korrektur

`BAR_HEIGHT = 148` (dritte Reihe): Schwierigkeit, `x1/x3/x10`, Pause, Saisonbalken. `StartMenu` ist ein nicht-blockierendes `CanvasLayer` (Layer 20). **Zusatzbefund:** bei 2560×1440 schnitt die alte `Main._fit_display()` mit `content_scale_factor = 1.333` die HUD rechts ab (sichtbarer Viewport nur 1440×810). Fix: Faktor `1.0` — `canvas_items` + `expand` skaliert bereits selbst. Bei 2560×1440 und 3440×1440 verifiziert.

---

## Weiterhin gültig (P0/P1/P2/REV1/REV2)

- **REVISION 2:** weiche 4px-Kanten für Höhlen/Wasser/Erdschichten (`TerrainContours.gd`), Höhlen ~50 % seltener (`cave_area_scale = 0.5`, Radien × √0.5), Wasser als **ein Becken** mit gemeinsamem Volumen und zeilenweise sinkendem Pegel (`WorldState.gd`). Jetzt zusätzlich **sichtbares Regen-Auffüllen**.
- **REVISION 1:** Vollbild ohne graue Ränder, organische Blob-Höhlen, fließende Oberfläche (`height_smooth_at()`, 4px), Eichel-Schwebe + freie Platzierung, Vogel erst nach Platzierung.
- **PHASE 2:** echte Wurzeln (`Tree → Roots → RootSegment`), Bodenpreise (Asche 8 … Stein 30 Glucose), Ghost-Preview, 5 Chunks à 2048 px, Nearest + Forward+, DE/EN.

## Ordnerstruktur

```
waldspiel/
├── project.godot                    # Godot 4.7.2, Forward+, Fullscreen, Nearest
├── GODOT-IMPORT.txt                 # Import-Anleitung (liegt auch in der ZIP)
├── DECISIONS.md                     # alle Annahmen (P0/P1/P2 + REV1/2 + PHASE 3 §§46-53)
├── PHASE3-ERGEBNIS.md + .html       # Bericht DIESER Runde (Screenshots + Snippets)
├── PHASE3-TESTPROTOKOLL.txt
├── REVISION2-ERGEBNIS.md + .html    # historische Berichte
├── tools/
│   ├── generate_placeholders.py     # erzeugt alle 19 PNGs neu (seed_mound.png neu)
│   ├── build_phase3_report.py       # Bericht mit 10 eingebetteten Screenshots
│   └── build_zip.py                 # vollständige Godot-ZIP
├── assets/placeholders/             # 19 PNGs + .import/.uid
├── data/localization.csv            # 76 Zeilen (Key, DE, EN), 17 neue P3-Keys
├── src/
│   ├── Main.gd / Main.tscn           # P3-Wiring, Presets, Space, _fit_display()
│   ├── autoload/Global.gd, EventBus.gd
│   ├── systems/                     # TimeManager, GrowthSystem, WaterSystem,
│   │                                # GrowthCost, SeasonSystem (NEU), SaveManager,
│   │                                # InteractionController
│   ├── ui/                          # HUD, StartMenu (NEU), BirdEvent, RainEffect
│   ├── world/, camera/, background/, plants/
├── tests/                           # 6 Smokes inkl. Phase3Smoke.gd (NEU)
└── screenshots/phase3_*.png         # 11 neue P3-Renders
```

## Tests

```bash
godot --headless --path . --import
godot --headless --path . --quit-after 180
godot --headless --path . -- --phase0-smoke       # Regression: OK
godot --headless --path . -- --phase1-smoke       # Regression: OK
godot --headless --path . -- --phase2-smoke       # Regression: OK
godot --headless --path . -- --rev1-smoke         # Regression: OK
godot --headless --path . -- --rev2-smoke         # Regression: OK
godot --headless --path . -- --p3-smoke           # PHASE 3: 55 Checks, OK
```

`--p3-smoke` prüft u. a. die beiden Vorab-Korrekturen, 15-min-Jahr, `scaled_delta` / Pause / x10, Winterruhe & kahlen Baum, alle drei Schwierigkeitsgrade inkl. Schalter, Startmenü, Eichel einsammeln / Hügel erst mit Wurzel, Herbstfall, Save-v4-Roundtrip, 5 Chunks, Nearest, Vollbild-Skalierung, DE/EN. **Wichtig:** Legacy-Smokes ohne `--seed` ausführen (P1 verlangt Zufalls-Seed). Beim ZIP-Extrakt-Test fiel `--rev1-smoke` bei einem ungünstigen Zufalls-Seed auf, weil er nur 26 Höhlen-Zeilen scannte; der Suchbereich ist jetzt wie in P2/REV2 auf `top+5 … top+45` vereinheitlicht (über 8 feste Seeds und 5 Zufallsläufe verifiziert).

Reproduzierbare Screenshots (Godot + Xvfb, `--seed=20261105 --windowed`):

```bash
--p3-shot-difficulty / --p3-shot-spring / --p3-shot-autumn / --p3-shot-winter
--p3-shot-seeds / --p3-shot-rain-refill / --p3-shot-bird-mid / --p3-shot-bird-exit
--rev2-shot-edges                         # Regression
--p3-debug-sizes                          # Viewport-/Skalierungs-Debug
```

## ZIP (vollständig, Godot-importierbar)

```bash
python3 tools/build_zip.py PHASE3   # -> /home/user/waldspiel-PHASE3.zip
```

`project.godot` liegt im **ZIP-Root**, `.godot/`-Cache und generierte `.translation` sind ausgeschlossen; alle Quellen, Assets, `.import`/`.uid`, Tests, Berichte und Screenshots sind drin. CRC-Test ist Teil des Skripts.

**Nächster Schritt: PHASE 4 — Skilltree-UI (GraphEdit, 15 Nodes, Glucose-Kosten, echte Effekte).**
