class_name TerrainContours
extends Node2D
## REVISION 2: „schoenere Kanten" fuer ALLE Untergrund-Strukturen.
##
## Genau wie TerrainSurface (Oberflaeche) zeichnet dieses Modul die sichtbaren
## Kanten in 4px-Schritten statt in harten 16px-Tile-Stufen:
##   * Erdschichten: fliessender Farbuebergang + dunkle Rim-Linie + heller Saum
##     (aus WorldGenerator.layer_edge_y(), folgt der Huegellinie).
##   * Hoehlen / Wasserreservoirs: die Tile-Belegung wird als bilineares
##     Vorzeichenfeld interpoliert (Abfrage direkt beim Generator, damit an
##     Chunk-Grenzen keine Lücken entstehen); die Isolinie f=0 ergibt
##     abgerundete Umrisse. Eine Noise-Wobble zerfranst den Rand zusaetzlich.
##   * Wasser: kleine Löcher werden morphologisch geschlossen, damit das
##     Reservoir ZUSAMMENHAENGT. Oberhalb des Pegels ist es hell/trocken,
##     darunter blau; eine helle Linie markiert den Wasserspiegel.
##
## Die alten 16px-Struktur-Tiles werden mit dem echten Boden-Atlas uebermalt,
## bevor die weiche Isolinie gezeichnet wird - sonst scheinen die Blockecken
## durch. Das TileMapLayer bleibt darunter für Logik/Kollision/Save/Load.
## Keine neuen Assets, keine Addons.

const SUB := 4.0
const SUB_PER_TILE := 4
const TS := 16.0
const CHUNK_W := 2048.0
const STEPS := 512                    # 2048 / 4
const BAND := 10.0
const MAX_WATER_GAP := 9              # 4px-Zellen: schliesst Loecher bis 32px

var index: int = 0
var origin: float = 0.0
var generator: WorldGenerator
var world_state: WorldState
var cave_tiles: Dictionary = {}       # Vector2i(gx,ty) -> true (global)
var water_tiles: Dictionary = {}

var _layers: Array = []
var _atlas: Texture2D

# Atlas-Grundtoene (tools/generate_placeholders.py, soil_atlas.png)
const C_ASH := Color(0.212, 0.196, 0.184)
const C_HUMUS := Color(0.227, 0.176, 0.137)
const C_TOPSOIL := Color(0.361, 0.259, 0.173)
const C_CLAY := Color(0.471, 0.318, 0.212)
const C_ROCK := Color(0.306, 0.325, 0.353)

const CAVE_FILL := Color(0.086, 0.094, 0.106)
const CAVE_RIM := Color(0.043, 0.047, 0.053)
const CAVE_LIGHT := Color(0.145, 0.153, 0.165)
const WATER_FILL := Color(0.204, 0.424, 0.588)
const WATER_RIM := Color(0.098, 0.235, 0.353)
const WATER_SURFACE := Color(0.573, 0.753, 0.839)
const DRY_FILL := Color(0.639, 0.616, 0.518)
const DRY_RIM := Color(0.43, 0.41, 0.35)


func setup(p_index: int, p_generator: WorldGenerator, p_state: WorldState,
		p_caves: Dictionary, p_water: Dictionary) -> void:
	index = p_index
	origin = float(p_index * WorldGenerator.CHUNK_WIDTH_PX)
	generator = p_generator
	world_state = p_state
	cave_tiles = p_caves
	water_tiles = p_water
	name = "Contours"
	z_index = 1                       # ueber tile_layer (0), neben TerrainSurface
	_atlas = load("res://assets/placeholders/soil_atlas.png") as Texture2D
	_layers = [
		{"depth": 16.0, "salt": 1.0, "top": C_ASH, "bottom": C_HUMUS},
		{"depth": 32.0, "salt": 2.0, "top": C_HUMUS, "bottom": C_TOPSOIL},
		{"depth": 208.0, "salt": 3.0, "top": C_TOPSOIL, "bottom": C_CLAY},
		{"depth": 608.0, "salt": 4.0, "top": C_CLAY, "bottom": C_ROCK},
	]
	if not EventBus.reservoir_level_changed.is_connected(_on_level_changed):
		EventBus.reservoir_level_changed.connect(_on_level_changed)
	queue_redraw()


func _on_level_changed() -> void:
	queue_redraw()


func _draw() -> void:
	if generator == null:
		return
	_erase_structure_tiles()
	_draw_layers()
	_draw_blobs(cave_tiles, 11.0, false)
	_draw_blobs(water_tiles, 29.0, true)


## Die alten 16px-Hoehlen-/Wasser-Tiles mit dem echten Boden-Atlas uebermalen.
func _erase_structure_tiles() -> void:
	if _atlas == null:
		return
	for tv in cave_tiles.keys():
		_erase_one(tv as Vector2i)
	for tv in water_tiles.keys():
		_erase_one(tv as Vector2i)


func _erase_one(t: Vector2i) -> void:
	var lx := float(t.x * int(TS)) - origin
	# REVISION 2: NUR Tiles des EIGENEN Chunks uebermalen. Wuerde ein
	# Rand-Tile des Nachbarn hier geloescht, aber (weil ausserhalb des
	# Zeichenbereichs) nicht neu gezeichnet, entstuende eine braune Naht
	# genau an der Chunk-Grenze.
	if lx < 0.0 or lx >= CHUNK_W:
		return
	var slot := generator.soil_slot_at(t.x, t.y)
	if slot < 0:
		return
	draw_texture_rect_region(_atlas,
		Rect2(lx, float(t.y * int(TS)), TS, TS),
		Rect2(float(slot * int(TS)), 0.0, TS, TS))


# --------------------------------------------------------------------------- #
# Erdschichten: weicher Farbuebergang + Rim + heller Saum
# --------------------------------------------------------------------------- #
func _draw_layers() -> void:
	for layer in _layers:
		var ys := PackedFloat32Array()
		ys.resize(STEPS + 1)
		for s in range(STEPS + 1):
			var lx := float(s) * SUB
			ys[s] = generator.layer_edge_y(origin + lx,
				float(layer["depth"]), float(layer["salt"]))
		var top: Color = layer["top"]
		var bottom: Color = layer["bottom"]
		var mid := Color((top.r + bottom.r) * 0.5,
			(top.g + bottom.g) * 0.5, (top.b + bottom.b) * 0.5, 0.78)
		var fade_top := Color(top.r, top.g, top.b, 0.0)
		var fade_bottom := Color(bottom.r, bottom.g, bottom.b, 0.0)

		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		for s in range(STEPS + 1):
			pts.append(Vector2(float(s) * SUB, ys[s] - BAND))
			cols.append(fade_top)
		for s in range(STEPS, -1, -1):
			pts.append(Vector2(float(s) * SUB, ys[s]))
			cols.append(mid)
		draw_polygon(pts, cols)

		pts = PackedVector2Array()
		cols = PackedColorArray()
		for s in range(STEPS + 1):
			pts.append(Vector2(float(s) * SUB, ys[s]))
			cols.append(mid)
		for s in range(STEPS, -1, -1):
			pts.append(Vector2(float(s) * SUB, ys[s] + BAND))
			cols.append(fade_bottom)
		draw_polygon(pts, cols)

		var prof := PackedVector2Array()
		var lite := PackedVector2Array()
		for s in range(STEPS + 1):
			prof.append(Vector2(float(s) * SUB, ys[s]))
			lite.append(Vector2(float(s) * SUB, ys[s] + 3.0))
		var rim := Color(top.r * 0.45, top.g * 0.45, top.b * 0.45, 0.85)
		var light := Color(minf(bottom.r * 1.35, 1.0),
			minf(bottom.g * 1.35, 1.0), minf(bottom.b * 1.35, 1.0), 0.55)
		draw_polyline(prof, rim, 2.0)
		draw_polyline(lite, light, 1.0)


# --------------------------------------------------------------------------- #
# Hoehlen / Wasser: abgerundete 4px-Isolinie statt 16px-Blockkante
# --------------------------------------------------------------------------- #
## Nachbar-Tiles direkt beim Generator abfragen (dort gecacht). Ein
## chunk-lokales Set wuerde an JEDEM Chunk-Uebergang eine Lücke erzeugen.
func _s(gx: int, gy: int, is_water: bool) -> float:
	var inside := (generator.reservoir_at(gx, gy) if is_water
		else generator.cave_at(gx, gy))
	return 1.0 if inside else -1.0


func _field(px: float, py: float, salt: float, is_water: bool) -> float:
	var tx := px / TS - 0.5
	var ty := py / TS - 0.5
	var gx0 := int(floor(tx))
	var gy0 := int(floor(ty))
	var fx := tx - float(gx0)
	var fy := ty - float(gy0)
	# Smoothstep -> leicht geschwungene statt geradlinige Isolinie.
	fx = fx * fx * (3.0 - 2.0 * fx)
	fy = fy * fy * (3.0 - 2.0 * fy)
	var v := lerpf(
		lerpf(_s(gx0, gy0, is_water), _s(gx0 + 1, gy0, is_water), fx),
		lerpf(_s(gx0, gy0 + 1, is_water), _s(gx0 + 1, gy0 + 1, is_water), fx),
		fy)
	return v + generator.edge_wobble_at(px, py, salt) * 0.85


## Kleine horizontale Löcher schliessen -> das Wasser „haengt zusammen".
func _close_water_gaps(filled: Dictionary, rows: Dictionary) -> void:
	for sy in rows.keys():
		var xs: Array = rows[sy]
		xs.sort()
		for i in range(xs.size() - 1):
			var a: int = xs[i]
			var b: int = xs[i + 1]
			if b - a > 1 and b - a <= MAX_WATER_GAP:
				for sx in range(a + 1, b):
					var c := Vector2i(sx, sy)
					if not filled.has(c):
						filled[c] = true
						xs.append(sx)


func _line_of(tile: Vector2i, cache: Dictionary) -> float:
	if cache.has(tile):
		return float(cache[tile])
	var line := world_state.waterline_px(tile.x, tile.y)
	cache[tile] = line
	return line


func _draw_blobs(cellset: Dictionary, salt: float, is_water: bool) -> void:
	if cellset.is_empty():
		return
	var active: Dictionary = {}
	for tv in cellset.keys():
		var t0: Vector2i = tv as Vector2i
		for ox in range(-1, 2):
			for oy in range(-1, 2):
				active[Vector2i(t0.x + ox, t0.y + oy)] = true

	# 1) Isolinie in 4px-Zellen abtasten.
	var filled: Dictionary = {}
	var rows: Dictionary = {}
	for tv in active.keys():
		var t: Vector2i = tv as Vector2i
		for i in SUB_PER_TILE:
			for j in SUB_PER_TILE:
				var sx := t.x * SUB_PER_TILE + i
				var sy := t.y * SUB_PER_TILE + j
				var px := float(sx * 4 + 2)
				var py := float(sy * 4 + 2)
				var lx := px - 2.0 - origin
				if lx < 0.0 or lx >= CHUNK_W:
					continue
				if _field(px, py, salt, is_water) < -0.02:
					continue
				var c := Vector2i(sx, sy)
				filled[c] = true
				if not rows.has(sy):
					rows[sy] = []
				rows[sy].append(sx)

	# 2) Beim Wasser kleine Löcher schliessen.
	if is_water:
		_close_water_gaps(filled, rows)

	# 3) Pro Zeile EINEN gemeinsamen Pegel bestimmen (vom ersten echten
	#    Reservoir-Tile), damit die Wasserflaeche horizontal zusammenhängt.
	var row_line: Dictionary = {}
	if is_water:
		for sy in rows.keys():
			var line := 1.0e9
			var xs: Array = rows[sy]
			xs.sort()
			for sx in xs:
				var tx := int(floor(float(sx * 4) / TS))
				var ty := int(floor(float(sy * 4) / TS))
				if generator.reservoir_at(tx, ty):
					line = world_state.waterline_px(tx, ty)
					break
			row_line[sy] = line

	# 4) Fuellen. Jede Zelle fragt den Pegel IHRES Beckens ab; nur die
	#    morphologisch geschlossenen Loecher (kein Reservoir-Tile) erben den
	#    Zeilenpegel. So koennen zwei benachbarte Becken unterschiedlich voll
	#    sein, ohne sich gegenseitig zu ueberschreiben.
	var line_cache: Dictionary = {}
	var wet: Dictionary = {}
	for cv in filled.keys():
		var c: Vector2i = cv as Vector2i
		var lx := float(c.x * 4) - origin
		var ly := float(c.y * 4)
		var col := CAVE_FILL
		if is_water:
			var tk := Vector2i(int(floor(float(c.x * 4) / TS)),
				int(floor(float(c.y * 4) / TS)))
			var line := _line_of(tk, line_cache)
			# Geschlossene Loecher gehoeren zu keinem Reservoir-Tile: den
			# Pegel vom naechsten echten Wasser-Tile DERSELBEN Zeile erben.
			if line >= 1.0e8:
				for dx in [0, -1, 1, -2, 2]:
					var near := Vector2i(tk.x + int(dx), tk.y)
					var nl := _line_of(near, line_cache)
					if nl < 1.0e8:
						line = nl
						break
			if line >= 1.0e8:
				line = float(row_line.get(c.y, 1.0e9))
			var is_wet: bool = (ly + 2.0) >= line
			if is_wet:
				wet[c] = true
				col = WATER_FILL
			else:
				col = DRY_FILL
		draw_rect(Rect2(lx, ly, SUB, SUB), col)

	# 5) Weiche Umrisslinie + Wasserlinie / Hoehlen-Glanz.
	for cv in filled.keys():
		var c: Vector2i = cv as Vector2i
		var lx := float(c.x * 4) - origin
		var ly := float(c.y * 4)
		var above := Vector2i(c.x, c.y - 1)
		var below := Vector2i(c.x, c.y + 1)
		var left := Vector2i(c.x - 1, c.y)
		var right := Vector2i(c.x + 1, c.y)
		var rim := CAVE_RIM
		if is_water:
			rim = WATER_RIM if wet.has(c) else DRY_RIM
		if not filled.has(above):
			draw_rect(Rect2(lx, ly, SUB, 2.0), rim)
			if is_water and wet.has(c):
				draw_rect(Rect2(lx, ly + 2.0, SUB, 1.0), WATER_SURFACE)
			elif not is_water:
				draw_rect(Rect2(lx, ly + 2.0, SUB, 1.0), CAVE_LIGHT)
		if not filled.has(below):
			draw_rect(Rect2(lx, ly + 2.0, SUB, 2.0), rim)
		# An der Chunk-Grenze setzt der Nachbar-Chunk die Kontur fort:
		# dort keine senkrechte Rim-Linie, sonst entsteht eine dunkle Naht.
		var at_left_edge := lx <= 0.0
		var at_right_edge := lx >= CHUNK_W - SUB
		if not filled.has(left) and not at_left_edge:
			draw_rect(Rect2(lx, ly, 2.0, SUB), rim)
		if not filled.has(right) and not at_right_edge:
			draw_rect(Rect2(lx + 2.0, ly, 2.0, SUB), rim)
		# Innerer Pegel: oben trocken, hier nass -> helle horizontale Linie.
		if is_water and wet.has(c) and filled.has(above) and not wet.has(above):
			draw_rect(Rect2(lx, ly, SUB, 2.0), WATER_SURFACE)
