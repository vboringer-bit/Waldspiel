class_name RainEffect
extends Control
## PHASE 1: Partikeleffekt "simple blaue Linien" (Punkt 4.2).
## Bildschirmraum, ohne Addon; nur sichtbar waehrend des Regen-Events.

const DROP_COUNT := 220

var raining: bool = false
var _drops: Array[Dictionary] = []


func _ready() -> void:
	# Explizite Rect-Groesse: ein Control unter einem CanvasLayer hat keinen
	# Control-Parent, Anker-Presets allein ergeben dort size == (0,0).
	position = Vector2.ZERO
	size = Vector2(get_viewport().get_visible_rect().size)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_to_group("rain_effect")
	visible = false
	var vp := size
	for _i in DROP_COUNT:
		_drops.append(_new_drop(vp.x, vp.y))
	EventBus.rain_started.connect(_on_rain_started)
	EventBus.rain_stopped.connect(_on_rain_stopped)
	get_viewport().size_changed.connect(_on_resize)


func _on_resize() -> void:
	size = Vector2(get_viewport().get_visible_rect().size)


func _new_drop(width: float, height: float) -> Dictionary:
	return {
		"x": randf() * width,
		"y": randf() * height,
		"speed": randf_range(520.0, 900.0),
		"len": randf_range(12.0, 26.0),
	}


func _on_rain_started(_duration: float) -> void:
	raining = true
	visible = true
	queue_redraw()


func _on_rain_stopped() -> void:
	raining = false
	visible = false


func _process(delta: float) -> void:
	if not raining:
		return
	var h := size.y
	for d in _drops:
		var y := float(d["y"]) + float(d["speed"]) * delta
		if y > h:
			d["y"] = -float(d["len"])
			d["x"] = randf() * size.x
		else:
			d["y"] = y
	queue_redraw()


func _draw() -> void:
	if not raining:
		return
	for d in _drops:
		var x := float(d["x"])
		var y := float(d["y"])
		var l := float(d["len"])
		draw_line(Vector2(x, y), Vector2(x - 4.0, y + l),
			Color(0.40, 0.66, 0.92, 0.72), 1.5)
