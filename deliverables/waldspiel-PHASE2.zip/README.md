# Wald-Regeneration — PHASE 2 / WACHSTUM & BODEN

> 2D-Seitenansicht (Himmel **und** Bodenquerschnitt) · Godot **4.7.2 stable** · GDScript · Forward+ / Vulkan
> Inspiriert von Mycelium / Mycelarium. Nach dem Waldbrand: 2 Eicheln, ein hungriger Vogel, ein Keimling mit wachsender Pfahlwurzel.

**Status:** PHASE 0 ✅ · PHASE 1 ✅ · **PHASE 2 ✅ (getestet)** · **PHASE 3 wurde nicht begonnen.**

**Am Ende jeder Phase gibt es zusätzlich eine komplette ZIP** (siehe unten).

---

## Starten

1. Godot 4.7.2 stable öffnen → `project.godot` importieren (oder die ZIP entpacken und `GODOT-IMPORT.txt` folgen).
2. **F5** (oder `godot --path .`).
3. Der **Welt-Seed wird bei jedem Neustart neu gewürfelt**. Für eine reproduzierbare Welt: `--seed=20261105` oder **Laden** (Seed steht im Savegame).

## Steuerung

| Eingabe | Wirkung |
|---|---|
| Linksklick auf Boden | Eichel pflanzen (1. → Vogel frisst sie, 2. → Keimling) |
| **MANUELL: Linksklick auf ein Wurzel-Segment** | Wurzel wächst in Erd-Richtung; Kosten nach Boden (Ghost-Preview zeigt Ziel + Preis) |
| MANUELL: Linksklick auf Baumkrone | Blatt wachsen (10 Glucose) |
| AUTO | Baum verteilt Glucose selbst (Wurzeln bei Durst, sonst Blätter) |
| Rechtsklick | Info (Baumwerte oder Bodenmaterial / Tiefe / Wurzel-Kosten / Seed) |
| `W A S D` / Maus am Rand | Kamera schwenken |
| Mausrad | Zoom `0.5x … 2.0x`, weich interpoliert |
| `R` | Regen sofort auslösen (Dev-Hook; echtes Intervall 2–5 Min) |
| HUD | AUTO/MANUELL, DE, Speichern, Laden |

Skilltree-Button = deaktivierter Platzhalter (PHASE 4). Zeit „Jahr 1 · Frühling" = Platzhalter (PHASE 3). Kein Tag/Nacht.

## Was PHASE 2 simuliert

- **Echte Wurzeln:** `Tree -> Roots -> RootSegment -> RootTip`, 16px-Raster, max. 32 Segmente. Eiche = Pfahlwurzel + Herzwurzelsystem (alle 4 Tiefen-Tiles eine Seitenwurzel als weiterer anklickbarer Tip).
- **Bodenhärte:** `GrowthCost` – Asche 8, Humus 9, **Mutterboden 10**, Lehm 13, Fels 25, Stein 30, Reservoir 15, Höhle 4 Glucose. AUTO und MANUELL zahlen identisch.
- **Ghost-Preview:** bei Mausbewegung im MANUELL-Modus grüner Rahmen + transparentes Wurzel-Sprite + Preis; rot bei zu wenig Glucose. Vorschau und Kauf nutzen dieselbe `propose_next_tile()`.
- **Wasserreservoirs:** `2.0/s` pro berührtem Tile statt `0.1/s` aus normalem Boden, Kapazität 60–120 Einheiten, **trocknen aus** und werden optisch heller (`SLOT_DRY_WATER`). Zustand bleibt über Chunk-Wechsel und Save/Load erhalten.
- **Höhlen:** dunkle, kollisionsfreie Hohlraum-Blasen (deterministische Ellipsen statt Noise-Sprenkel), Wurzelwachstum dort am billigsten.
- **HUD:** zusätzlich Wurzel-Kosten und Reservoir-Füllstand in %.
- **Speichern v2:** Wurzel-Segmente + Reservoir-Zustand; liest auch PHASE-1-Spielstände (v1).

## Ordnerstruktur

```
waldspiel/
├── project.godot                    # Godot 4.7.2, Forward+, 1920x1080, Nearest
├── GODOT-IMPORT.txt                 # Import-Anleitung (liegt auch in der ZIP)
├── DECISIONS.md                     # alle Annahmen (PHASE 0 + 1 + 2)
├── README.md
├── PHASE0/1/2-ERGEBNIS.md + .html   # Ergebnisberichte (Bilder offline eingebettet)
├── tools/
│   ├── generate_placeholders.py     # erzeugt alle 18 PNGs neu (17 Atlas-Slots)
│   ├── build_phase0_report.py
│   ├── build_phase1_report.py
│   ├── build_phase2_report.py
│   └── build_zip.py                 # vollständige Godot-ZIP (jede Phase)
├── assets/placeholders/             # Boden-Atlas, Sprites, Icons, Himmel/Berge
├── data/
│   ├── localization.csv             # Key, DE, EN (alle Phasen)
│   ├── species/oak.tres             # TreeSpeciesData (inkl. root_side_every)
│   └── skilltrees/                  # PHASE 4
├── src/
│   ├── Main.gd / Main.tscn
│   ├── autoload/                    # Global (Zufallsseed), EventBus
│   ├── world/                       # WorldGenerator, TerrainAtlas, Chunk,
│   │                                # ChunkManager, WorldState
│   ├── camera/CameraController.gd
│   ├── background/                  # SkyBackground, MountainBackdrop
│   ├── plants/                      # Tree.gd (BaseTree), Oak.gd, RootSegment.gd
│   ├── systems/                     # GrowthCost, GrowthSystem, WaterSystem,
│   │                                # TimeManager, SaveManager, InteractionController
│   ├── data/TreeSpeciesData.gd
│   └── ui/                          # HUD, RainEffect, BirdEvent, GhostPreview
├── tests/                           # Phase0Smoke.gd, Phase1Smoke.gd, Phase2Smoke.gd
└── screenshots/                     # phase0_*.png, phase1_*.png, phase2_*.png
```

## Tests

```bash
godot --headless --path . --import
godot --headless --path . --quit-after 180        # F5-Ersatz
godot --headless --path . -- --phase0-smoke       # Regression
godot --headless --path . -- --phase1-smoke       # Regression, 25 Checks
godot --headless --path . -- --phase2-smoke       # 24 Checks, Exit 0
```

`--phase2-smoke` prüft u. a. Höhlen-Determinismus, kollisionsfreie Höhlen, 10-Glucose-Referenz, Fels > Lehm > Mutterboden > Höhle, RootTip-Hierarchie, Wurzelklick + Kosten, Ghost-Preview, Reservoir-Kontakt, 2.0/s-Boost, abnehmende Kapazität, Austrocknen + helles Tile, Save/Load v2, 5 Chunks und DE/EN. Erwartung: `[SMOKE] Ergebnis: OK`, **keine roten Fehler**.

Reproduzierbare Screenshots (Godot + Xvfb):

```bash
--seed=20261105 --phase2-shot-caves       # Höhlen + Wasserlinsen
--seed=20261105 --phase2-shot-roots       # Pfahlwurzel bis ins Reservoir
--seed=20261105 --phase2-shot-manual      # MANUELL + Ghost-Preview + Kosten
--seed=20261105 --phase2-shot-dry         # ausgetrocknetes (helles) Reservoir
--seed=20261105 --phase1-shot-bird / -planted / -rain
--seed=20261105 --phase0-shot-soil / -pan
```

## ZIP (ab sofort am Ende jeder Phase)

```bash
python3 tools/build_zip.py PHASE2   # -> /home/user/waldspiel-PHASE2.zip
```

`project.godot` liegt im **ZIP-Root**, `.godot/`-Cache und generierte `.translation` sind ausgeschlossen; alle Quellen, Assets, `.import`/`.uid`, Tests, Berichte und Screenshots sind drin. CRC-Test ist Teil des Skripts.

## Platzhalter / Berichte neu erzeugen

```bash
python3 tools/generate_placeholders.py
python3 tools/build_phase2_report.py
python3 tools/build_zip.py PHASE2
```

Details und Begründungen: **[DECISIONS.md](DECISIONS.md)** · Ergebnis: **[PHASE2-ERGEBNIS.md](PHASE2-ERGEBNIS.md)** / **[PHASE2-ERGEBNIS.html](PHASE2-ERGEBNIS.html)**.
