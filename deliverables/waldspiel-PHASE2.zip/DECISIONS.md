# DECISIONS.md — begründete Annahmen (PHASE 0 + 1 + 2)

Datum: 2026-11-05 · Engine: **Godot 4.7.2 stable** (`4.7.2.stable.official.ed1daf0bf`) · Sprache: GDScript

Der Master-Prompt sagt: *„Frage nach, wenn eine Design-Entscheidung unklar ist, aber triff sonst sinnvolle Annahmen und dokumentiere sie in DECISIONS.md.“* Es gab keine blockierende Unklarheit; alle Annahmen stehen hier. **Gebaut: PHASE 0, PHASE 1 und PHASE 2. PHASE 3 wurde nicht begonnen.** Abschnitte 1–10 = PHASE 0, 11–20 = PHASE 1, 21–31 = PHASE 2.

---

## 1. Phasengrenze (wichtigste Entscheidung)

PHASE 0 = *„Leeres Projekt, Ordnerstruktur, Platzhalter-Pixel, Kamera mit Zoom/Pan, ChunkManager der unebenen Boden generiert (Hügel, 1 Biom, Fels unten).“*

> **Hinweis (Stand PHASE 1):** Abschnitte 1–10 beschreiben den Stand *nach PHASE 0*. Die dort als „noch nicht enthalten" aufgezählten Punkte sind inzwischen teilweise durch PHASE 1 ergänzt – siehe Abschnitt 13.

**Enthalten:** `project.godot`, komplette Ordnerstruktur, 15 selbst generierte Platzhalter-PNGs, Kamera (Zoom/Pan), `WorldGenerator`, `ChunkManager`, `TerrainChunk`, `TerrainAtlas`, Himmel + Berg-Silhouette, verkohlte Stümpfe/Äste als **reine Deko**, Info-Overlay, Headless-Smoke-Test, DE/EN-CSV-Infrastruktur.

**Bewusst NICHT enthalten** (strikte Phasentreue): 2 Eicheln/Inventar, Vogel-Event, Keimung, Glucose/Wasser, Regen, Auto/Manuell, manuelles Wurzelwachstum, Wasserreservoirs, Höhlen, Jahreszeiten, Schwierigkeitsgrade, Skilltree, Tiere, Pilze, Parasiten, Speichern/Laden-Button, finales HUD, Ambient-Sound.

Die verkohlten Stümpfe (16×32 = 2 Tiles) und die Berg-Silhouette sind **nur Grafik** (Punkt 2 „Szenario Start“ / „nur als Silhouette, keine Kollision“), also Setup und keine Spielmechanik. Es gibt keine lebenden Bäume.

## 2. Raster & Geometrie

| Entscheidung | Wert | Grund |
|---|---|---|
| Pixelgröße | `16x16` = 1 Tile | Punkt 2, nicht verhandelbar |
| Chunkbreite | `2048 px` = `128 Tiles` | Punkt 3.1 |
| Tiefe | `68 Tiles` ≈ `1088 px` ≈ 1 Bildschirm | Punkt 3.1 |
| Mittlere Oberfläche | Welt-Y `320` | genug Himmel über dem Boden bei 1920×1080 |
| Fels-Basement | globaler Tile-Y `88` (Welt-Y `1408`), fest | „Tiefer geht es nicht“; verhindert ausgefranste Unterkante bei Hügeln |
| Höhenlinie | `FastNoiseLite` (Simplex Smooth + Detail), auf 16 px gesnappt | Hügel + Pixel-Perfektion |
| Schichtgrenzen | Tile 0 = Asche (0–16 px), Tile 1 = Humus (16–32 px), Tiles 2–12 = Mutterboden (32–208 px), Tiles 13–37 = Lehm (208–608 px), ab Tile 38 = Fels (ab 608 px) | Die 20/200/600-px-Angaben aus Punkt 3.1 auf das 16er-Raster gerundet. Abweichung ≤ 1 Tile, dokumentiert statt „krumme“ Pixel. |

Tiefe wird **relativ zur lokalen Oberfläche** gemessen: ein Hügel verschiebt alle Schichten mit. Steinklumpen werden bereits noise-basiert eingestreut (Punkt 3.1). Wasserreservoirs, Lufttaschen/Höhlen und Mykorrhiza-Pixel sind als Atlas-Slots 11/12/14/15 sowie `Material.WATER/CAVE` **vorbereitet, aber nicht generiert** (PHASE 2/5).

## 3. Biome

PHASE 0 liefert exakt **1 Biom (temperiert)**. `biome_at()`, `biome_moisture_at()` und `biome_noise_at()` sind bereits vorhanden; `biome_moisture_at()` gibt konstant `0.5` zurück. Die Smoothstep-Blende über 2–3 Chunks (links trocken / rechts feucht) folgt in PHASE 3, damit PHASE 0 nicht halb implementierte Biome zeigt.

## 4. Kollision & TileSet

`TileSet` wird zur Laufzeit aus `soil_atlas.png` gebaut (`TileSetAtlasSource`, Physics Layer 0, 16×16-Polygon pro Tile). Pro Slot existieren 3 Alternative Tiles (gespiegelt / leicht abgedunkelt), damit das 16er-Raster nicht als sichtbares Muster repetiert; die Asche-Oberfläche bleibt ungespiegelt, damit die verbrannte Kante oben bleibt. Grund: keine fragile `.tres`-Datei mit Sub-Resource-IDs; der Atlas bleibt direkt austauschbar. In PHASE 0 gibt es **keinen physics body**, der die Kollision abfragt — die Kollisionsschicht ist Vorbereitung für Wurzel-/Samen-Physik in PHASE 2 und wird dort gegen echte Bodies getestet.

## 5. Texturen & Import

- Alle Grafiken stammen aus `tools/generate_placeholders.py` (Pillow, nur Generierungszeit — das Spiel braucht kein Python). **Keine Fremd-Assets.**
- Global: `rendering/textures/canvas_textures/default_texture_filter=0` (**Nearest**), `default_texture_repeat=0`, `use_nearest_mipmap_filter=false`; PNG-Import-Dateien werden von Godot mit `mipmaps/generate=false` erzeugt.
- **Einzige Ausnahme** laut Punkt 2: Himmel-Gradient, Sonnen-Dunst und Berg-Silhouetten sind höher aufgelöst und nutzen pro Node `TEXTURE_FILTER_LINEAR`.
- `stretch/mode="canvas_items"`, `aspect="expand"`, `viewport 1920×1080`, `snap_2d_*_to_pixel=true`, `TileMapLayer.y_sort_enabled=true`.

## 6. Kamera

Mausrad → Zielzoom mit `clamp(0.5, 2.0)` und exponentiellem Lerp (smooth). WASD + Maus am Rand pannen; X unbegrenzt (infinite Chunks), Y auf `-350 … 1000` begrenzt, damit man Himmel und Fels-Basement sieht aber nicht ins Leere fährt. `teleport_to()` ist die öffentliche Schnittstelle für Save/Load, „Kamera folgt Baum“ und den Smoke-Test.

Input-Actions (`pan_left/right/up/down`) werden in `Global._ready()` per `InputMap` registriert statt in `project.godot`. Das ist robuster als handgeschriebene `InputEventKey`-Objekte in der Config und bleibt bei jedem Checkout identisch.

## 7. Hintergrund

Der Himmel ist ein bildschirmfester `CanvasLayer` (`layer=-100`) **hinter** der Welt; Boden-Tiles überdecken ihn, sobald die Kamera nach unten fährt. Berge liegen im Weltraum (`z_index=-20`) mit X-Parallax `0.18` / `0.38` und 6 nahtlos gekachelten Kopien. Beide Ebenen haben **keine Kollision** (Punkt 2: „erst später per Progression erreichbar“).

## 8. Lokalisierung

`data/localization.csv` (Key, DE, EN) wird in `Global._setup_localization()` zur Laufzeit geparst und als zwei `Translation`-Objekte am `TranslationServer` registriert; PHASE-0-Texte nutzen bereits `tr()`. Escaped `\n` in CSV-Feldern wird zu echten Zeilenumbrüchen aufgelöst. Seit PHASE 1 schaltet ein DE/EN-Button im HUD `Global.locale` um (`TranslationServer` + `EventBus.locale_changed`); ein vollwertiger Einstellungs-Dialog kann spaeter folgen.

## 9. Referenz-Repos (Stand: PHASE 1)

| Repo | Status | Verwendung |
|---|---|---|
| `GDQuest/godot-procedural-generation` | ✅ erreichbar | `make_seed_for()`-Idee → `chunk_seed()`, Sektor-Refresh um Kamera-X (`_refresh()`), nur neue Chunks erzeugen / alte freigeben. **Weiterhin aktiv.** |
| `Tdead1/GodotGeneration` | ✅ erreichbar (neu, PHASE 1) | Godot-3-Projekt (`config_version=4`), 20×20-Tile-Grid, `RandomNumberGenerator.seed`, Nachbarschafts-Smoothing und Item-Platzierung. Muster **notiert** für PHASE 2 (Höhlen-Smoothing) und PHASE 5 (Wald-Konkurrenz). Kein Code übernommen. |
| `funferall/RHIZOMORPH` | ✅ erreichbar | Boden-Querschnitt / Substrat-Denken, CPU-Fallback + grobes Grid als Architektur-Notiz für PHASE 2/5 |
| `DrJamgo/GodotGpuConwaysLife` | ✅ erreichbar | Tile-Grid / GPU-Feld als Notiz für Wald-Konkurrenz (PHASE 5) |
| `SeldonHh/Godot_skill_tree_maker` | ✅ erreichbar | Ressourcen-basierte Skill-Nodes als Notiz für PHASE 4 |
| `Arsenic-er/Game-Super-boring-fungi` | ✅ erreichbar | Mutations-/Upgrade-Struktur als Notiz für PHASE 4/5 |
| `marcus-zitzelsbergerit/godot-pixel-sculpt` | ❌ **404, vom Nutzer bestätigt** | **Ignoriert** (keine lokale Kopie vorhanden) |
| `marcus-zitzelsbergerit/godot-poly-sculpt` | ❌ **404, vom Nutzer bestätigt** | **Ignoriert** (keine lokale Kopie vorhanden) |

Der Nutzer hat entschieden: *„Ignoriere sie … Oder baue Chunk- und Height-Logik selbst mit FastNoiseLite (height_at(x) + ChunkManager mit 2048px Chunks) wie im Master-Prompt Punkt 3.1 beschrieben. Keine externen Addons nötig.“* Genau das ist seit PHASE 0 der Fall und bleibt so: `WorldGenerator.height_at()`, `chunk_seed()`, `ChunkManager` mit 2048px-Chunks, `TileMapLayer`. **Keine externen Addons, kein kopierter Code.**

## 10. Verifikation (PHASE 0)

Getestet mit dem echten Godot-4.7.2-Binary:

1. `godot --headless --path . --import` — Assets importieren.
2. `godot --headless --path . -- --phase0-smoke` — Determinismus, 5 Chunks, Nachladen über 5+ Chunks, Schichtfolge.
3. `godot --headless --path . --quit-after 120` — F5-Ersatz.
4. Xvfb + `--write-movie` — drei echte Screenshots (Start, Boden bis Fels, Pan auf x=4300).

`project.godot` deklariert **Forward+ / Vulkan**. Für Screenshots im Sandbox (keine GPU) wurde Xvfb mit Software-Rendering verwendet; das ändert nichts an den Projekteinstellungen.

---

# PHASE 1 — zusätzliche Entscheidungen (2026-11-05)

## 11. Zufalls-Seed (User-Antwort 1)

`Global._resolve_seed()` würfelt bei **jedem Prozessstart** `randi_range(1, 2147483646)`, nachdem der globale RNG mit `Time.get_unix_time_from_system() * 1000 + Time.get_ticks_usec()` neu geseedet wurde. Drei Teststarts ergaben drei verschiedene Seeds. „Gleiche Seed = gleiche Welt" bleibt gültig:

- `--seed=<int>` / `--phase1-seed=<int>` setzt den Seed reproduzierbar (Tests, Screenshots).
- `SaveManager` schreibt den Seed nach `user://savegame.json` und stellt ihn beim Laden wieder her (`Global.set_seed_from_save()` + `ChunkManager.set_world_seed()`).
- `Global.seed_is_random` dokumentiert im Smoke-Test, dass der Seed gewürfelt wurde.

## 12. Save/Load schon in PHASE 1

Der Master ordnet Speichern **keiner** Phase explizit zu, verlangt es aber in Punkt 9 und in den MVP-Akzeptanzkriterien („Speichern/Laden Button funktioniert"). Wegen des Zufalls-Seeds wäre dieselbe Welt nach einem Neustart sonst unerreichbar → bewusst bereits in PHASE 1 geliefert. JSON: `version, seed, auto_mode, locale, inventory, bird_event_done, trees[]` (Position + Glucose/Wasser/Health/Alter/Blätter/Wurzeln/Stamm). Runtrip wird im Smoke-Test geprüft.

## 13. Phasengrenze PHASE 1 (strikt)

**Enthalten:** 2 Eicheln, Linksklick-Platzierung, Vogel-Event (Tween-Animation), Keimling (2 Stamm-Tiles / 2 Blätter / 1 Wurzel), `Tree.gd` + `Oak.gd` + `TreeSpeciesData` (`oak.tres`), Fotosynthese, Wasser (Boden `root_count * 0.1/s`, Regen 5x), Regen-Event 120–300 s / 20–60 s mit blauen Linien, AUTO/MANUELL, HUD (Glucose+Icon, Wasserbalken, Inventar, Zeit-Platzhalter, Toggle, DE/EN, Speichern/Laden, Skilltree-Platzhalter), Rechtsklick-Info, Toast-Nachrichten.

**Bewusst NICHT enthalten** (PHASE 2+): richtungsbasiertes Wurzelwachstum, Bodenhärte/Kosten, Ghost-Preview, endliche/austrocknende Wasserreservoirs, Höhlen, L-System, art-spezifische Wurzelformen in der Simulation, Jahreszeiten/Zeitspulen, Schwierigkeitsgrade, Herbst-Eichelfall, Samen finden/vergraben, Skilltree-UI, Tiere, Pilz-Symbiose, Parasiten, Ambient-Sound.

## 14. MANUELL in PHASE 1 bewusst minimal

Der Toggle muss laut PHASE 1 „funktionieren". Deshalb: **AUTO** kauft selbst (Durst `water < 40` → Wurzel, sonst Blatt, 10 Glucose); **MANUELL** kauft per Klick (Klick unter der Oberfläche → Wurzel, darüber → Blatt, 10 Glucose). PHASE 2 ersetzt das durch Wachstum in Erd-Richtung mit Bodenhärte, Reservoir-Zielen und Ghost-Preview. Caps: 12 Blätter / 12 Wurzeln / 12 Stamm-Tiles pro Baum, max. 100 Bäume (Punkt 9).

## 15. Tutorial & Testbarkeit

1. Eichel: Vogel fliegt per Tween rein, `MSG_BIRD_EVENT` („Die Natur ist hungrig. Versuche es erneut."), Inventar 2→1, **kein** Baum. 2. Eichel: Keimung. Das echte Regen-Intervall (2–5 Min) bleibt unverändert; für Demo/Tests gibt es Taste `R`, `WaterSystem.force_rain()` und CLI-Presets. Screenshot-Presets `--phase1-shot-{bird,tree,rain}` + `--seed=` sind reproduzierbar.

## 16. Zeit / Schwierigkeit / Skilltree

`TimeManager.gd` liefert nur „Jahr 1 · Frühling" (PHASE 3). `Global.difficulty` bleibt `NORMAL`; LEICHT (0.2/s Bodenwasser, keine Katastrophen) und SCHWER (pH/N/P/K, Mykorrhiza) kommen in PHASE 3 – daher gelten die NORMAL-Werte 0.1/s und 0.35/s Verbrauch. Der Skilltree-Button ist sichtbar, aber deaktiviert (PHASE 4). **Kein Tag/Nacht-Zyklus.**

## 17. Klassennamen

`Tree.gd` hat `class_name BaseTree`, weil Godot eine native `Tree`-Control-Klasse hat (sonst Parse-Fehler „shadows a native class", analog zu `Material` → `SoilKind` in PHASE 0). `Oak.gd` nutzt `extends "res://src/plants/Tree.gd"`, also wörtlich `extends Tree` über den Pfad. `Phase0Overlay.gd` bleibt als PHASE-0-Artefakt im Repo, ist aber nicht mehr in `Main.tscn` eingehängt (ersetzt durch das echte `HUD.gd`).

## 18. Regen-Rendering

`RainEffect` ist ein `Control` unter einem `CanvasLayer`. `set_anchors_preset()` allein ergab ohne Control-Parent `size = (0,0)` → unsichtbare Linien. Fix: explizite `size` aus `get_viewport().get_visible_rect()` plus `size_changed`-Signal. 220 Linien via `_draw()`, keine Addons. Im Smoke-Test über die Gruppe `rain_effect` geprüft.

## 19. Verifikation PHASE 1

| Prüfung | Ergebnis |
|---|---|
| `--headless --import` | Exit 0 / 0 Fehler |
| `--headless --quit-after 120` (F5-Ersatz) | Exit 0 / 0 Fehler |
| `-- --phase0-smoke` (Regression) | Exit 0 / `Ergebnis: OK` |
| `-- --phase1-smoke` (25 Checks) | Exit 0 / `Ergebnis: OK` |
| 4 Xvfb-Screenshots | 0 Fehler |
| 3 Neustarts | 3 unterschiedliche Seeds |
| DE/EN `tr()`, Regen-Partikel, Save/Load-Roundtrip | im Smoke-Test OK |

## 20. Nächster Schritt

Die PHASE 2 wurde am 2026-11-05 freigegeben und ist in den Abschnitten 21–31 dokumentiert. **PHASE 3 erst nach neuem OK.**


---

# PHASE 2 — zusätzliche Entscheidungen (2026-11-05)

## 21. Phasengrenze PHASE 2 (strikt)

Der Master-Prompt sagt: *„PHASE 2 – Wachstum & Boden: Manuelles Wachstum (klicke Wurzel -> wächst in Erd-Richtung, kostet Glucose), Boden-Typen kosten unterschiedlich, Wasserreservoirs (endlich, austrocknend), Höhlen."* Zusätzlich aus Punkt 4.2: `water_gain = 2.0 * dt` bei Reservoir-Kontakt, `capacity` nimmt ab, leer = optisch heller, und *„Zeige Ghost-Preview wohin Wurzel wachsen würde"*. Aus Punkt 4.3: Wachstum kostet abhängig von Bodenhärte (Fels teurer), Eiche = Pfahlwurzel + Herzwurzelsystem.

**Enthalten:** echte Wurzel-Segmente mit `RootTip`-Hierarchie, Klick auf Segment → Wachstum in Erd-Richtung, `GrowthCost`-Tabelle, Ghost-Preview, endliche Reservoirs mit Austrocknung + hellem Tile, Höhlen als kollisionsfreie Hohlraum-Blasen, Speichern v2 (Wurzel-Segmente + Reservoir-Zustand), HUD-Anzeige für Kosten und Reservoir-Füllstand, DE/EN-Texte.

**Bewusst NICHT enthalten** (PHASE 3+): Jahreszeiten/Zeitspulen, Herbst-Eichelfall, Samen finden/vergraben, Schwierigkeitsgrade, Buche/Kiefer, L-System-Verzweigung über der Erde, natürliche Vermehrung, Skilltree-UI (GraphEdit), Tiere, Pilz-Symbiose, Parasiten, Ambient-Sound.

## 22. Wurzel-Segmente statt Zähler

PHASE 1 kannte nur `root_count`. PHASE 2 führt `src/plants/RootSegment.gd` ein: jedes Segment hat eine `grid`-Position (Tiles relativ zum Baum), eine `direction`, einen Parent und Kinder. `BaseTree` hält `root_segments[]` und ein `_occupied`-Raster; `deepest_tip()` / `tip_for()` finden das Ende eines Astes. `MAX_ROOTS` wurde von 12 auf **32** erhöht, damit die Pfahlwurzel Reservoire in Tiefe 10–12 erreichen kann. Die PHASE-1-API (`add_root()`, `grow_part("root")`, `root_count`) bleibt erhalten – daher laufen `Phase0Smoke` und `Phase1Smoke` unverändert grün.

## 23. Art-spezifische Wurzelrichtung (Eiche)

`Oak.gd` überschreibt `root_candidates()`: die Hauptachse wächst strikt `(0,1)` (Pfahlwurzel), Ausweichziele sind diagonal; Seitenwurzeln biegen wieder nach unten. Alle `root_side_every = 4` Tiefen-Tiles erzeugt `grow_root_from()` zusätzlich eine Seitenwurzel als **weiteren anklickbaren Tip** (Herzwurzelsystem), ohne die Hauptachse zu unterbrechen. Daten stehen in `data/species/oak.tres`; Buche (Flachwurzler) und Kiefer (sehr tiefe Pfahlwurzel) kommen in PHASE 3 mit eigenen Werten/`root_candidates()`.

## 24. Boden-Kosten: 10 Glucose bleibt der Referenzwert

Das Akzeptanzkriterium *„Klick auf Wurzel -> kostet 10 Glucose"* wird als **Mutterboden = 10** interpretiert. `GrowthCost.gd` hat eine zentrale Tabelle: Asche `0.8` (8), Humus `0.9` (9), Mutterboden `1.0` (**10**), Lehm `1.3` (13), Fels `2.5` (25), Stein `3.0` (30), Reservoir `1.5` (15), Höhle `0.4` (4). Fels ist damit deutlich teurer, Hohlräume fast frei. Blatt-/Stamm-Wachstum kostet weiter den art-spezifischen Basispreis 10 (oberirdisch, keine Bodenhärte). **AUTO zahlt dieselben bodenabhängigen Kosten** wie MANUELL.

## 25. Ghost-Preview

`src/ui/GhostPreview.gd` zeigt bei Mausbewegung im MANUELL-Modus das nächste freie Erd-Tile: halbtransparentes Wurzelspitzen-Sprite, grüner Rahmen (rot bei zu wenig Glucose) und ein Label mit Bodenmaterial + Preis. `InteractionController.update_ghost()` und der tatsächliche Kauf benutzen **dieselbe** Funktion `BaseTree.propose_next_tile()` – Vorschau und Ergebnis können nicht auseinanderlaufen. Das HUD spiegelt die Werte über `EventBus.ghost_preview`.

## 26. Reservoirs: endlich, austrocknend, savebar

**Wo** ein Reservoir liegt, bestimmt allein der Seed (`WorldGenerator.reservoir_at`). **Wie voll** es noch ist, ist Laufzeit-Zustand in `src/world/WorldState.gd` (kein Autoload, vom `ChunkManager` besessen und an alle Systeme weitergereicht). Ohne diese Trennung würde ein neu geladener Chunk nach Regen/Neuimport wieder volles Wasser liefern. Kapazität 60–120 Einheiten pro Tile, Verbrauch `2.0/s` pro berührtem Wurzel-Segment. Bei 0: `EventBus.reservoir_dried` → `TerrainChunk` malt das Tile auf `SLOT_DRY_WATER` (deutlich heller) um; der Zustand bleibt über Chunk-Wechsel und Save/Load erhalten.

## 27. Höhlen

Höhlen sind dunkle `SLOT_CAVE`-Tiles ohne Kollisions-Polygon (`TerrainAtlas`), also Hohlräume im Bodenquerschnitt. Die Kosten für Wurzelwachstum sind dort am geringsten. Es gibt **keinen** Grab-/Abbau-Modus und keine begehbaren Tunnel – das wäre über den MVP-Rahmen hinaus. Sichtbare, geschlossene Höhlenkammern statt 1-Tile-Sprenkel: Ellipsen-Blasen auf einem Zellraster (siehe Abschnitt 28).

## 28. Blobs statt Noise-Sprenkel (Iterations-Entscheidung)

Der erste Ansatz (`FastNoiseLite`-Threshold pro Tile) erzeugte visuell „Fernseh-Rauschen": hunderte einzelne schwarze/blaue Pixel. Deshalb jetzt deterministische Ellipsen-Blasen: pro `(Seed, Zellindex)` wird mit `hash()` entschieden, ob eine Zelle eine Blase enthält, plus Position und Radius. Höhlen: 16×10-Zellen, Radius ~4×3 Tiles, ~62 % Belegung, Tiefe 6–40. Reservoirs: 13×9-Zellen, Radius ~2.8×2, ~45 %, Tiefe 7–34. Ergebnisse werden pro Tile memoisisiert (`_cave_cache`, `_res_cache`), damit der Chunk-Aufbau nicht 1,5 Mio. Hashes pro Frame rechnet.

## 29. Garantiertes Starter-Reservoir

Damit das Tutorial und die Screenshots das neue Feature **zuverlässig** zeigen, gibt es in Chunk 0 eine feste Wasserlinse: globale Tiles `x = -6 … 6`, Tiefe 10–12 relativ zur lokalen Oberfläche. Alle weiteren Reservoirs kommen aus den Blobs. Das ist eine bewusste Annahme (der Master nennt keine Verteilung); dokumentiert, seed-unabhängig und deshalb in jedem Savegame erreichbar. Die Breite von 13 Tiles toleriert die leichte Kamera-Drift durch Maus-am-Rand im Headless-Modus.

## 30. Save-Format v2 (rückwärtskompatibel)

`FORMAT_VERSION = 2`. Neu: `world_state` (`dry[]`, `remaining{}`) und pro Baum `root_segments[]` mit Grid, Richtung, Parent-Index und Tip-Flag. `BaseTree.from_dict()` akzeptiert auch alte **v1**-Spielstände ohne Segmente und baut dann aus dem bloßen `roots`-Zähler eine einfache Kette. Reihenfolge beim Laden: Seed setzen → Chunks neu bauen → `WorldState` wiederherstellen → `refresh_dry_tiles()` → Bäume rekonstruieren.

## 31. ZIP als dauerhafter Phasen-Abschluss (User-Anweisung)

Der Nutzer hat am 2026-11-05 gesagt: *„Schick mir am Ende nach Fertigstellung immer zusätzlich eine vollständige zip Datei die ich in godot einfügen kann."* Das gilt ab sofort **für jede weitere Phase**. `tools/build_zip.py <PHASE>` erzeugt `/home/user/waldspiel-<PHASE>.zip` mit `project.godot` im ZIP-Root; `.godot/`-Cache und generierte `.translation` werden ausgeschlossen, alle Quellen/Assets/Berichte/Screenshots eingeschlossen. `GODOT-IMPORT.txt` liegt im ZIP-Root und erklärt den Import. Die ZIP wird zusätzlich zum HTML-Ergebnisbericht übergeben.

## 32. Verifikation PHASE 2

| Prüfung | Ergebnis |
|---|---|
| `--headless --import` (18 PNGs, 17 Atlas-Slots) | Exit 0 / 0 Fehler |
| `--headless --quit-after 180` (F5-Ersatz) | Exit 0 / 0 Fehler |
| `-- --phase0-smoke` (Regression) | Exit 0 / `Ergebnis: OK` |
| `-- --phase1-smoke` (Regression, 25 Checks) | Exit 0 / `Ergebnis: OK` |
| `-- --phase2-smoke` (24 Checks) | Exit 0 / `Ergebnis: OK` |
| 4 Xvfb-Screenshots (`--phase2-shot-*`) | 0 Fehler |
| ZIP-CRC-Test + `project.godot` im Root | OK |

## 33. Nächster Schritt

**PHASE 3 erst nach deinem OK:** Jahreszeiten (15–20 Min/Jahr), Zeitspulen x1/x3/x10 + Pause, Herbst-Eichelfall, Samen finden/vergraben, Schwierigkeitsgrade (LEICHT/NORMAL/SCHWER), Buche/Kiefer.
