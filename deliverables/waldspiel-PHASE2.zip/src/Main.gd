extends Node2D
## Einstiegsszene. Verdrahtet die modularen Systeme; enthaelt selbst keine
## Spiellogik. PHASE 0 (Welt/Kamera), PHASE 1 (Kern-Loop) und PHASE 2
## (Wachstum & Boden) laufen hier zusammen.

@onready var _sky: SkyBackground = $SkyBackground
@onready var _mountains: MountainBackdrop = $World/MountainBackdrop
@onready var _chunk_manager: ChunkManager = $World/ChunkManager
@onready var _camera: CameraController = $World/WorldCamera
@onready var _trees: Node2D = $World/Trees
@onready var _bird_layer: BirdEvent = $World/BirdLayer
@onready var _ghost: GhostPreview = $World/GhostPreview
@onready var _growth: GrowthSystem = $Systems/GrowthSystem
@onready var _water: WaterSystem = $Systems/WaterSystem
@onready var _time: TimeManager = $Systems/TimeManager
@onready var _save: SaveManager = $Systems/SaveManager
@onready var _interaction: InteractionController = $Interaction
@onready var _hud: HUD = $HUD


func _ready() -> void:
	var args := OS.get_cmdline_args() + OS.get_cmdline_user_args()
	_chunk_manager.setup(_camera)
	_mountains.setup(_camera)
	_sky.refresh_layout()
	var state := _chunk_manager.world_state
	_growth.setup(_chunk_manager.generator)
	_water.setup(state, _chunk_manager.generator)
	_interaction.setup(_camera, _chunk_manager, _trees, _bird_layer,
		_water, _growth, state, _ghost)
	_save.setup(_interaction, _chunk_manager, state)
	_hud.setup(_interaction, _growth, _water, _time, _save, state)
	_apply_presets(args)

	# Headless-Tests (kein Addon):
	#   godot --headless --path . -- --phase0-smoke
	#   godot --headless --path . -- --phase1-smoke
	#   godot --headless --path . -- --phase2-smoke
	if args.has("--phase0-smoke"):
		var smoke0 = preload("res://tests/Phase0Smoke.gd").new()
		smoke0.setup(_chunk_manager, _camera)
		add_child(smoke0)
	elif args.has("--phase1-smoke"):
		var smoke1 = preload("res://tests/Phase1Smoke.gd").new()
		smoke1.setup(_interaction, _growth, _water, _save, _chunk_manager, _camera)
		add_child(smoke1)
	elif args.has("--phase2-smoke"):
		var smoke2 = preload("res://tests/Phase2Smoke.gd").new()
		smoke2.setup(_interaction, _growth, _water, _save,
			_chunk_manager, _camera, state, _ghost)
		add_child(smoke2)

	print("[Main] PHASE 2 bereit: %d Eicheln, Kern-Loop, Wurzel-Segmente, Bodenhärte, Reservoirs, Höhlen." % [
		_interaction.get_seed_count()])


## Reproduzierbare Zustaende fuer Screenshots / Tests.
## Ohne Argument: F5 startet mit 2 Eicheln und zufaelligem Seed.
func _apply_presets(args: PackedStringArray) -> void:
	if args.has("--phase2-shot-caves"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 700.0))
	elif args.has("--phase2-shot-roots"):
		_camera.set_zoom_immediate(1.25)
		_camera.teleport_to(Vector2(0.0, 490.0))
		_interaction.debug_plant_twice()
		_interaction.debug_grow_roots(14)
		_water.set_process(false)
	elif args.has("--phase2-shot-manual"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 390.0))
		_interaction.debug_plant_twice()
		Global.auto_mode = false
		_growth.set_process(false)
		_interaction.debug_grow_roots(3)
		_interaction.selected_tree.glucose = 42.0
		_interaction.debug_show_ghost()
		_hud.refresh_texts()
		_hud.refresh()
	elif args.has("--phase2-shot-dry"):
		_camera.set_zoom_immediate(1.0)
		_camera.teleport_to(Vector2(0.0, 700.0))
		_interaction.debug_drain_reservoirs()
	elif args.has("--phase1-shot-bird"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_first_seed()
	elif args.has("--phase1-shot-planted"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_plant_twice()
		_growth.debug_advance(5.0)
	elif args.has("--phase1-shot-rain"):
		_camera.set_zoom_immediate(1.6)
		_camera.teleport_to(Vector2(0.0, 370.0))
		_interaction.debug_plant_twice()
		_growth.debug_advance(2.0)
		_water.force_rain(30.0)
	elif args.has("--phase0-shot-soil"):
		_camera.set_zoom_immediate(0.85)
		_camera.teleport_to(Vector2(0.0, 790.0))
	elif args.has("--phase0-shot-pan"):
		_camera.set_zoom_immediate(0.75)
		_camera.teleport_to(Vector2(4300.0, 500.0))
