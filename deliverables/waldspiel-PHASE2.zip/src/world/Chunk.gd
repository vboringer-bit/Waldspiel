class_name TerrainChunk
extends Node2D
## Ein horizontaler Chunk (2048 px). Besitzt genau eine TileMapLayer fuer den
## Bodenquerschnitt und einen Decor-Root fuer die Brand-Rueckstaende.
## PHASE 2: Hoehlen (CAVE) und Reservoirs (WATER) kommen aus dem Generator;
## ausgetrocknete Reservoirs werden ueber WorldState auf SLOT_DRY_WATER
## umgeschaltet und bleiben auch nach einem Chunk-Reload trocken.

const SPRITE_DIR := "res://assets/placeholders/"

var index: int = 0
var generator: WorldGenerator
var world_state: WorldState
var tile_layer: TileMapLayer
var decor_root: Node2D


func setup(p_index: int, p_generator: WorldGenerator, p_tile_set: TileSet,
		p_world_state: WorldState) -> void:
	index = p_index
	generator = p_generator
	world_state = p_world_state
	name = "Chunk_%d" % index
	position = Vector2(float(index * WorldGenerator.CHUNK_WIDTH_PX), 0.0)
	_build_terrain(p_tile_set)
	_build_decor()
	EventBus.reservoir_dried.connect(_on_reservoir_dried)


func _build_terrain(p_tile_set: TileSet) -> void:
	tile_layer = TileMapLayer.new()
	tile_layer.name = "Terrain"
	tile_layer.tile_set = p_tile_set
	tile_layer.rendering_quadrant_size = 16
	tile_layer.collision_enabled = true
	tile_layer.y_sort_enabled = true
	add_child(tile_layer)

	for lx in WorldGenerator.CHUNK_TILES_X:
		var gx := index * WorldGenerator.CHUNK_TILES_X + lx
		var top := generator.surface_tile_y_at(float(gx * WorldGenerator.TILE_SIZE))
		for ty in range(top, WorldGenerator.BOTTOM_TILE_Y + 1):
			var slot := _slot_for(gx, ty)
			if slot >= 0:
				var alt := 0 if ty == top else generator.alternative_at(gx, ty)
				tile_layer.set_cell(Vector2i(lx, ty), 0, Vector2i(slot, 0), alt)


func _slot_for(gx: int, ty: int) -> int:
	if generator.cave_at(gx, ty):
		return WorldGenerator.SLOT_CAVE
	if generator.reservoir_at(gx, ty):
		if world_state != null and world_state.is_dry(gx, ty):
			return WorldGenerator.SLOT_DRY_WATER
		return WorldGenerator.SLOT_WATER
	return generator.atlas_slot_at(gx, ty)


func _on_reservoir_dried(tile: Vector2i) -> void:
	var lx := tile.x - index * WorldGenerator.CHUNK_TILES_X
	if lx < 0 or lx >= WorldGenerator.CHUNK_TILES_X or tile_layer == null:
		return
	if not generator.reservoir_at(tile.x, tile.y):
		return
	tile_layer.set_cell(Vector2i(lx, tile.y), 0,
		Vector2i(WorldGenerator.SLOT_DRY_WATER, 0), 0)


## Nach Save/Load: alle sichtbaren Reservoirs passend neu einfaerben.
func refresh_reservoirs() -> void:
	if tile_layer == null or world_state == null:
		return
	for lx in WorldGenerator.CHUNK_TILES_X:
		var gx := index * WorldGenerator.CHUNK_TILES_X + lx
		var top := generator.surface_tile_y_at(float(gx * WorldGenerator.TILE_SIZE))
		for ty in range(top, WorldGenerator.BOTTOM_TILE_Y + 1):
			if generator.reservoir_at(gx, ty) and world_state.is_dry(gx, ty):
				tile_layer.set_cell(Vector2i(lx, ty), 0,
					Vector2i(WorldGenerator.SLOT_DRY_WATER, 0), 0)


func _build_decor() -> void:
	decor_root = Node2D.new()
	decor_root.name = "Decor"
	decor_root.y_sort_enabled = true
	add_child(decor_root)

	for d in generator.decorations_for_chunk(index):
		var tex: Texture2D = load(SPRITE_DIR + String(d["kind"]) + ".png")
		if tex == null:
			push_warning("[Chunk] Platzhalter fehlt: %s" % d["kind"])
			continue
		var sprite := Sprite2D.new()
		sprite.name = String(d["kind"])
		sprite.texture = tex
		sprite.centered = false
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.position = Vector2(float(d["x"]), float(d["y"]))
		decor_root.add_child(sprite)
