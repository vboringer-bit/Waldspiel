class_name WorldGenerator
extends RefCounted
## Reine, deterministische Weltberechnung - keine Nodes, keine Side-Effects.
## Gleiche Seed + gleiche X-Koordinate => identische Hoehe / identisches Material.
## Inspiriert von GDQuest godot-procedural-generation (make_seed_for / Sektoren)
## und der Idee einer oeffentlichen height_at()-Abfragefunktion.
##
## PHASE 2 ergaenzt: Hoehlen (CAVE), endliche Wasserreservoirs (WATER),
## Bodenhärte/Growth-Kosten und die art-unabhaengige Tile-Geometrie.

enum SoilKind { AIR, ASH, HUMUS, TOPSOIL, CLAY, ROCK, STONE, WATER, CAVE }
enum BiomeKind { TROCKEN, TEMPERIERT, FEUCHT }

const TILE_SIZE := 16
const CHUNK_TILES_X := 128
const CHUNK_WIDTH_PX := 2048          # 128 * 16
const DEPTH_TILES := 68               # ~1088 px = ca. 1 Bildschirmtiefe
const BASE_SURFACE_Y := 320.0         # Horizont / mittlere Oberflaeche
const BOTTOM_TILE_Y := 88             # Fels-Basement: hier ist Schluss

# Atlas-Slots (siehe tools/generate_placeholders.py)
const SLOT_ASH := 0
const SLOT_HUMUS := 1
const SLOT_TOPSOIL_A := 2
const SLOT_TOPSOIL_B := 3
const SLOT_TOPSOIL_STONE := 4
const SLOT_CLAY_A := 5
const SLOT_CLAY_B := 6
const SLOT_CLAY_STONE := 7
const SLOT_ROCK_A := 8
const SLOT_ROCK_B := 9
const SLOT_ROCK_DEEP := 10
const SLOT_WATER := 11                # PHASE 2: Reservoir (nass)
const SLOT_CAVE := 12                 # PHASE 2: Hohlraum
const SLOT_ASH_ALT := 13
const SLOT_MOSS := 14                 # PHASE 5 reserviert
const SLOT_ROOTED := 15               # PHASE 2 reserviert
const SLOT_DRY_WATER := 16            # PHASE 2: ausgetrocknet (optisch heller)

# Garantiertes Starter-Reservoir in Chunk 0 (Tutorial / Screenshot / Tests).
# Lokal relativ zur Oberflaeche, damit es trotz Huegel immer unter dem Keimling
# liegt. Alle weiteren Reservoirs und Hoehlen kommen aus Noise. Siehe DECISIONS.
const STARTER_RESERVOIR_MIN_X := -6
const STARTER_RESERVOIR_MAX_X := 6
const STARTER_RESERVOIR_MIN_DEPTH := 10
const STARTER_RESERVOIR_MAX_DEPTH := 12

var world_seed: int = 0

var _height_noise := FastNoiseLite.new()
var _detail_noise := FastNoiseLite.new()
var _variation_noise := FastNoiseLite.new()
var _stone_noise := FastNoiseLite.new()
var _biome_noise := FastNoiseLite.new()
var _cave_noise := FastNoiseLite.new()
var _reservoir_noise := FastNoiseLite.new()


func _init(p_seed: int = 20261105) -> void:
	set_world_seed(p_seed)


func set_world_seed(p_seed: int) -> void:
	world_seed = p_seed
	_cave_cache.clear()
	_res_cache.clear()
	_configure(_height_noise, p_seed, 1, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 3, 0.50)
	_configure(_detail_noise, p_seed, 2, FastNoiseLite.TYPE_SIMPLEX, 2, 0.45)
	_configure(_variation_noise, p_seed, 3, FastNoiseLite.TYPE_VALUE, 2, 0.50)
	_configure(_stone_noise, p_seed, 4, FastNoiseLite.TYPE_CELLULAR, 1, 0.50)
	_configure(_biome_noise, p_seed, 5, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 2, 0.50)
	_configure(_cave_noise, p_seed, 6, FastNoiseLite.TYPE_SIMPLEX_SMOOTH, 2, 0.50)
	_configure(_reservoir_noise, p_seed, 7, FastNoiseLite.TYPE_SIMPLEX, 2, 0.45)


func _configure(n: FastNoiseLite, s: int, salt: int, type: int, octaves: int, gain: float) -> void:
	n.seed = s + salt * 7919
	n.noise_type = type
	n.frequency = 1.0
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = octaves
	n.fractal_gain = gain
	n.fractal_lacunarity = 2.0


# --------------------------------------------------------------------------- #
# Hoehenlinie
# --------------------------------------------------------------------------- #
## Oberflaeche in Welt-Y, auf das 16px-Raster gesnappt => pixel-perfekt.
func height_at(world_x: float) -> float:
	var broad := _height_noise.get_noise_1d(world_x / 1000.0)
	var fine := _detail_noise.get_noise_1d(world_x / 170.0)
	var raw := BASE_SURFACE_Y + broad * 52.0 + fine * 10.0
	return roundf(raw / float(TILE_SIZE)) * float(TILE_SIZE)


func surface_tile_y_at(world_x: float) -> int:
	return int(height_at(world_x) / float(TILE_SIZE))


func depth_tiles_at(global_tile_x: int, tile_y: int) -> int:
	return tile_y - surface_tile_y_at(float(global_tile_x * TILE_SIZE))


# --------------------------------------------------------------------------- #
# Biome (PHASE 0-2: exakt 1 Biom, aber API + Noise fuer 3 Biome vorbereitet)
# --------------------------------------------------------------------------- #
func biome_at(_world_x: float) -> BiomeKind:
	return BiomeKind.TEMPERIERT


## 0.0 = trocken, 0.5 = temperiert, 1.0 = feucht.
## PHASE 3: smoothstep-Blend ueber 2-3 Chunks links/rechts + dieser Noise.
func biome_moisture_at(_world_x: float) -> float:
	return 0.5


func biome_noise_at(world_x: float) -> float:
	return _biome_noise.get_noise_1d(world_x / 6000.0)


# --------------------------------------------------------------------------- #
# PHASE 2: Hoehlen + Wasserreservoirs (deterministisch, seed-abhaengig)
# --------------------------------------------------------------------------- #
# Kohaerente Ellipsen-Blasen auf einem Zellraster statt verstreuter
# 1-Tile-Noise-Sprenkel. Jede Zelle enthaelt mit ~density% Wahrscheinlichkeit
# eine Blase; Position und Radius kommen aus (Seed, Zellindex). Dadurch sind
# Hoehlen auch optisch Hohlraeume und Reservoirs abgrenzbare Wasserlinsen.
const CAVE_CELL_W := 16
const CAVE_CELL_H := 10
const RES_CELL_W := 13
const RES_CELL_H := 9

var _cave_cache: Dictionary = {}
var _res_cache: Dictionary = {}


func is_starter_reservoir(global_tile_x: int, tile_y: int) -> bool:
	if global_tile_x < STARTER_RESERVOIR_MIN_X or global_tile_x > STARTER_RESERVOIR_MAX_X:
		return false
	var d := depth_tiles_at(global_tile_x, tile_y)
	return d >= STARTER_RESERVOIR_MIN_DEPTH and d <= STARTER_RESERVOIR_MAX_DEPTH


func _hash2(a: int, b: int, salt: int) -> int:
	return ("%d_%d_%d_%d" % [world_seed, salt, a, b]).hash() & 0x7fffffff


func _blob_at(global_tile_x: int, tile_y: int, cell_w: int, cell_h: int,
		salt: int, radius_x: float, radius_y: float, density: int) -> bool:
	var cx := int(floor(float(global_tile_x) / float(cell_w)))
	var cy := int(floor(float(tile_y) / float(cell_h)))
	for ox in range(-1, 2):
		for oy in range(-1, 2):
			var ccx := cx + ox
			var ccy := cy + oy
			var h := _hash2(ccx, ccy, salt)
			if (h % 100) >= density:
				continue
			var h2 := _hash2(ccx, ccy, salt + 7919)
			var h3 := _hash2(ccx, ccy, salt + 15839)
			var bx := float(ccx * cell_w) + float(h2 % cell_w)
			var by := float(ccy * cell_h) + float(h3 % cell_h)
			var rx := radius_x * (0.75 + float(h % 7) * 0.07)
			var ry := radius_y * (0.75 + float(h3 % 7) * 0.07)
			var dx := (float(global_tile_x) - bx) / maxf(rx, 0.001)
			var dy := (float(tile_y) - by) / maxf(ry, 0.001)
			if dx * dx + dy * dy <= 1.0:
				return true
	return false


func _compute_cave(global_tile_x: int, tile_y: int) -> bool:
	if is_starter_reservoir(global_tile_x, tile_y):
		return false
	var d := depth_tiles_at(global_tile_x, tile_y)
	if d < 6 or d > 40 or tile_y > BOTTOM_TILE_Y:
		return false
	return _blob_at(global_tile_x, tile_y, CAVE_CELL_W, CAVE_CELL_H, 61, 4.2, 3.0, 62)


func cave_at(global_tile_x: int, tile_y: int) -> bool:
	var k := Vector2i(global_tile_x, tile_y)
	if _cave_cache.has(k):
		return _cave_cache[k]
	var v := _compute_cave(global_tile_x, tile_y)
	_cave_cache[k] = v
	return v


func _compute_reservoir(global_tile_x: int, tile_y: int) -> bool:
	if is_starter_reservoir(global_tile_x, tile_y):
		return true
	if cave_at(global_tile_x, tile_y):
		return false
	var d := depth_tiles_at(global_tile_x, tile_y)
	if d < 7 or d > 34 or tile_y > BOTTOM_TILE_Y:
		return false
	return _blob_at(global_tile_x, tile_y, RES_CELL_W, RES_CELL_H, 71, 2.8, 2.0, 45)


func reservoir_at(global_tile_x: int, tile_y: int) -> bool:
	var k := Vector2i(global_tile_x, tile_y)
	if _res_cache.has(k):
		return _res_cache[k]
	var v := _compute_reservoir(global_tile_x, tile_y)
	_res_cache[k] = v
	return v


## Start-Kapazitaet eines Reservoirs in Wasser-Einheiten (2.0/s Verbrauch).
func reservoir_capacity_at(global_tile_x: int, tile_y: int) -> float:
	var h := ("%d_res_%d_%d" % [world_seed, global_tile_x, tile_y]).hash() & 0x7fffffff
	return 60.0 + float(h % 61)   # 60 .. 120


# --------------------------------------------------------------------------- #
# Boden-Schichtung (PHASE 2: Hoehlen/Reservoirs ueberlagern das Gestein)
# --------------------------------------------------------------------------- #
func material_at(global_tile_x: int, tile_y: int) -> SoilKind:
	var surface_ty := surface_tile_y_at(float(global_tile_x * TILE_SIZE))
	if tile_y < surface_ty or tile_y > BOTTOM_TILE_Y:
		return SoilKind.AIR
	if cave_at(global_tile_x, tile_y):
		return SoilKind.CAVE
	if reservoir_at(global_tile_x, tile_y):
		return SoilKind.WATER
	var depth_tiles := tile_y - surface_ty
	if depth_tiles == 0:
		return SoilKind.ASH
	if depth_tiles == 1:
		return SoilKind.HUMUS
	if depth_tiles <= 12:
		return SoilKind.TOPSOIL
	if depth_tiles <= 37:
		return SoilKind.CLAY
	return SoilKind.ROCK


## Liefert den Atlas-Slot fuer ein Tile oder -1 fuer Luft.
func atlas_slot_at(global_tile_x: int, tile_y: int) -> int:
	var surface_ty := surface_tile_y_at(float(global_tile_x * TILE_SIZE))
	if tile_y < surface_ty or tile_y > BOTTOM_TILE_Y:
		return -1
	if cave_at(global_tile_x, tile_y):
		return SLOT_CAVE
	if reservoir_at(global_tile_x, tile_y):
		return SLOT_WATER
	var depth_tiles := tile_y - surface_ty
	var variation := _variation_noise.get_noise_2d(
		float(global_tile_x) * 0.35, float(tile_y) * 0.35)
	var has_stone := _stone_noise.get_noise_2d(
		float(global_tile_x) * 1.3, float(tile_y) * 1.3) > 0.42

	if depth_tiles == 0:
		return SLOT_ASH_ALT if variation > 0.25 else SLOT_ASH
	if depth_tiles == 1:
		return SLOT_HUMUS
	if depth_tiles <= 12:
		if has_stone and depth_tiles > 3:
			return SLOT_TOPSOIL_STONE
		return SLOT_TOPSOIL_A if variation < 0.0 else SLOT_TOPSOIL_B
	if depth_tiles <= 37:
		if has_stone and depth_tiles > 15:
			return SLOT_CLAY_STONE
		return SLOT_CLAY_A if variation < 0.0 else SLOT_CLAY_B
	if depth_tiles > 55:
		return SLOT_ROCK_DEEP
	return SLOT_ROCK_A if variation < 0.0 else SLOT_ROCK_B


## Alternative Tile-ID (0 = Basis, 1-3 = gespiegelte/abgedunkelte Varianten).
## Nur fuer Tiles UNTER der Oberflaeche benutzen: bei Asche wuerde flip_v die
## verbrannte Oberkante nach unten drehen. Spezial-Slots bleiben ungespiegelt.
func alternative_at(global_tile_x: int, tile_y: int) -> int:
	var slot := atlas_slot_at(global_tile_x, tile_y)
	if slot == SLOT_CAVE or slot == SLOT_WATER or slot == SLOT_DRY_WATER:
		return 0
	var n := _variation_noise.get_noise_2d(
		float(global_tile_x) * 0.71 + 31.0, float(tile_y) * 0.71 - 17.0)
	if n > 0.35:
		return 3
	if n > 0.0:
		return 1
	if n > -0.35:
		return 2
	return 0


# --------------------------------------------------------------------------- #
# Chunk-Dekoration (Start-Zustand: verkohlte Stuempfe / Aeste, keine Baeume)
# --------------------------------------------------------------------------- #
## Seed pro Chunk: Welt-Seed + Index => unabhaengig von Ladereihenfolge.
func chunk_seed(chunk_index: int) -> int:
	return ("%d_chunk_%d" % [world_seed, chunk_index]).hash() & 0x7fffffff


func decorations_for_chunk(chunk_index: int) -> Array[Dictionary]:
	var rng := RandomNumberGenerator.new()
	rng.seed = chunk_seed(chunk_index)
	var out: Array[Dictionary] = []
	var used: Array[int] = []

	# Start-Chunk: 4 Stuempfe (Master-Prompt: 3-5), sonst 1-2 zur Deko.
	var stump_count := 4 if chunk_index == 0 else rng.randi_range(1, 2)
	for _i in stump_count:
		var tx := _spread_x(rng, used)
		used.append(tx)
		var wx := float(chunk_index * CHUNK_WIDTH_PX + tx * TILE_SIZE)
		out.append({
			"x": float(tx * TILE_SIZE),
			"y": height_at(wx) - float(TILE_SIZE * 2),  # Stuempfe sind 2 Tiles hoch
			"kind": "stump_%s" % ["a", "b", "c"][rng.randi_range(0, 2)],
		})

	for _i in rng.randi_range(1, 3):
		var tx := _spread_x(rng, used)
		used.append(tx)
		var wx := float(chunk_index * CHUNK_WIDTH_PX + tx * TILE_SIZE)
		out.append({
			"x": float(tx * TILE_SIZE),
			"y": height_at(wx) - float(TILE_SIZE),
			"kind": "branch",
		})
	return out


func _spread_x(rng: RandomNumberGenerator, used: Array[int]) -> int:
	var tx := rng.randi_range(4, CHUNK_TILES_X - 6)
	for _attempt in 12:
		if not _too_close(tx, used, 14):
			break
		tx = rng.randi_range(4, CHUNK_TILES_X - 6)
	return tx


func _too_close(x: int, used: Array[int], min_distance: int) -> bool:
	for other in used:
		if absi(x - other) < min_distance:
			return true
	return false
