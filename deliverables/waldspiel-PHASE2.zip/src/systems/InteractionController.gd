class_name InteractionController
extends Node
## PHASE 1: Linksklick = Interaktion (Eichel pflanzen / Baum auswählen),
## Rechtsklick = Info. Mausrad + WASD bleiben PHASE 0.
## PHASE 2: Klick auf ein Wurzel-Segment laesst es in Erd-Richtung wachsen;
## die Kosten haengen vom Boden des Ziel-Tiles ab (GrowthCost). Eine
## Ghost-Preview zeigt bei Mausbewegung im MANUELL-Modus Ziel + Preis.

const STARTING_SEEDS := 2
const MAX_TREES := 100
const ACORN_PATH := "res://assets/placeholders/acorn.png"

var seed_count: int = STARTING_SEEDS
var first_seed_eaten: bool = false
var selected_tree: BaseTree = null

var camera: Camera2D
var generator: WorldGenerator
var trees_root: Node2D
var bird_layer: BirdEvent
var water_system: WaterSystem
var growth_system: GrowthSystem
var world_state: WorldState
var ghost: GhostPreview

var _next_id: int = 1


func setup(p_camera: Camera2D, p_chunk_manager: ChunkManager, p_trees_root: Node2D,
		p_bird_layer: BirdEvent, p_water: WaterSystem, p_growth: GrowthSystem,
		p_world_state: WorldState = null, p_ghost: GhostPreview = null) -> void:
	camera = p_camera
	generator = p_chunk_manager.generator
	trees_root = p_trees_root
	bird_layer = p_bird_layer
	water_system = p_water
	growth_system = p_growth
	world_state = p_world_state
	ghost = p_ghost


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key := event as InputEventKey
		if key.pressed and not key.echo and key.keycode == KEY_R:
			water_system.force_rain(30.0)
			get_viewport().set_input_as_handled()
		return
	if event is InputEventMouseMotion:
		if not Global.auto_mode and camera != null:
			update_ghost(camera.get_global_mouse_position())
		return
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if not mb.pressed or camera == null:
		return
	var world_pos := camera.get_global_mouse_position()
	if mb.button_index == MOUSE_BUTTON_LEFT:
		_left_click(world_pos)
	elif mb.button_index == MOUSE_BUTTON_RIGHT:
		_right_click(world_pos)


func _left_click(pos: Vector2) -> void:
	# PHASE 2: im MANUELL-Modus hat ein Wurzelklick Vorrang vor der Baum-Auswahl.
	if not Global.auto_mode:
		var hit := find_root_hit(pos)
		if not hit.is_empty():
			manual_root_growth(hit["tree"], hit["segment"])
			return
	var tree := find_tree_at(pos)
	if tree != null:
		if Global.auto_mode:
			select_tree(tree)
		else:
			manual_growth(tree, pos)
		return
	if seed_count <= 0:
		EventBus.toast.emit(tr("MSG_NO_SEEDS"))
		return
	if pos.y < generator.height_at(pos.x):
		EventBus.toast.emit(tr("MSG_SOIL_ONLY"))
		return
	plant_seed_at(pos)


func _right_click(pos: Vector2) -> void:
	var tree := find_tree_at(pos)
	if tree != null:
		select_tree(tree)
		EventBus.toast.emit(tree.get_info_text())
		return
	var gx := int(floor(pos.x / float(WorldGenerator.TILE_SIZE)))
	var ty := int(floor(pos.y / float(WorldGenerator.TILE_SIZE)))
	var kind := generator.material_at(gx, ty)
	var depth := int(maxf(pos.y - generator.height_at(pos.x), 0.0))
	var cost := GrowthCost.for_tile(generator, gx, ty)
	EventBus.toast.emit(tr("MSG_SOIL_INFO") % [
		GrowthCost.material_name(kind), depth, cost, Global.world_seed])


# --------------------------------------------------------------------------- #
# Eicheln & Keimung
# --------------------------------------------------------------------------- #
func plant_seed_at(pos: Vector2, instant: bool = false) -> bool:
	if seed_count <= 0:
		return false
	seed_count -= 1
	EventBus.inventory_changed.emit(seed_count)
	EventBus.seed_placed.emit(pos)
	if not instant:
		_spawn_acorn_sprite(pos)

	# 1. Eichel: scripted Vogel-Event
	if not first_seed_eaten:
		first_seed_eaten = true
		EventBus.seed_eaten.emit(pos)
		if not instant:
			bird_layer.spawn_bird(pos, false)
		EventBus.toast.emit(tr("MSG_BIRD_EVENT"))
		return true

	# 2. Eichel: Keimung
	if trees_root.get_child_count() >= MAX_TREES:
		return false
	var tree := spawn_tree_at(pos, {})
	select_tree(tree)
	EventBus.toast.emit(tr("MSG_GERMINATED"))
	return true


func spawn_tree_at(pos: Vector2, data: Dictionary) -> BaseTree:
	var snapped := Vector2(
		roundf(pos.x / float(WorldGenerator.TILE_SIZE)) * float(WorldGenerator.TILE_SIZE),
		generator.height_at(pos.x))
	return _create_tree(snapped, data)


func spawn_tree_from_dict(d: Dictionary) -> BaseTree:
	var pos := Vector2(float(d.get("x", 0.0)), float(d.get("y", 0.0)))
	var tree := _create_tree(pos, d)
	tree.tree_id = int(d.get("id", tree.tree_id))
	_next_id = maxi(_next_id, tree.tree_id + 1)
	return tree


func _create_tree(pos: Vector2, data: Dictionary) -> BaseTree:
	var tree = preload("res://src/plants/Oak.gd").new()
	trees_root.add_child(tree)
	tree.global_position = pos
	tree.world_generator = generator
	tree.tree_id = _next_id
	_next_id += 1
	tree.setup(null, tree.tree_id, data)
	EventBus.tree_spawned.emit(tree)
	return tree


func _spawn_acorn_sprite(pos: Vector2) -> void:
	var s := Sprite2D.new()
	s.texture = load(ACORN_PATH)
	s.centered = false
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.position = pos - Vector2(8.0, 16.0)
	trees_root.add_child(s)
	var tw := create_tween()
	tw.tween_interval(0.6)
	tw.tween_property(s, "modulate:a", 0.0, 0.6)
	tw.tween_callback(s.queue_free)


# --------------------------------------------------------------------------- #
# Auswahl / Wurzel-Hit / Ghost-Preview
# --------------------------------------------------------------------------- #
func find_tree_at(pos: Vector2) -> BaseTree:
	for tree in get_tree().get_nodes_in_group("trees"):
		if tree.get_bounds_rect().has_point(pos):
			return tree
	return null


func find_root_hit(world_pos: Vector2) -> Dictionary:
	for tree in get_tree().get_nodes_in_group("trees"):
		var seg: RootSegment = tree.find_root_segment_at(world_pos)
		if seg != null:
			return {"tree": tree, "segment": seg}
	return {}


func select_tree(tree: BaseTree) -> void:
	selected_tree = tree
	EventBus.tree_selected.emit(tree)


func refresh_selection() -> void:
	var trees := get_tree().get_nodes_in_group("trees")
	selected_tree = trees[0] if trees.size() > 0 else null
	EventBus.tree_selected.emit(selected_tree)


## Zeigt im MANUELL-Modus, wohin die Wurzel wachsen wuerde und was es kostet.
func update_ghost(world_pos: Vector2) -> void:
	if ghost == null or Global.auto_mode:
		_hide_ghost()
		return
	var hit := find_root_hit(world_pos)
	if hit.is_empty():
		_hide_ghost()
		return
	var tree: BaseTree = hit["tree"]
	var segment: RootSegment = hit["segment"]
	var tip := tree.tip_for(segment)
	var target := tree.propose_next_tile(tip)
	if target == BaseTree.INVALID_TILE:
		_hide_ghost()
		return
	var gt := tree.global_tile_for(target)
	var kind := generator.material_at(gt.x, gt.y)
	var cost := GrowthCost.for_tile(generator, gt.x, gt.y)
	var affordable := tree.glucose >= cost
	var material := GrowthCost.material_name(kind)
	ghost.show_at(Vector2(float(gt.x * WorldGenerator.TILE_SIZE),
		float(gt.y * WorldGenerator.TILE_SIZE)), cost, affordable, material)
	EventBus.ghost_preview.emit(gt, cost, affordable, material)


func _hide_ghost() -> void:
	if ghost != null:
		ghost.hide_ghost()
	EventBus.ghost_preview.emit(Vector2i(-1, -1), 0.0, false, "")


# --------------------------------------------------------------------------- #
# Manuelles Wachstum (PHASE 2)
# --------------------------------------------------------------------------- #
## Klick auf eine Wurzel: naechstes Tile in Erd-Richtung, Kosten = Bodenhärte.
func manual_root_growth(tree: BaseTree, segment: RootSegment) -> bool:
	if tree == null:
		return false
	var tip := tree.tip_for(segment)
	var target := tree.propose_next_tile(tip)
	if target == BaseTree.INVALID_TILE:
		EventBus.toast.emit(tr("MSG_ROOT_BLOCKED"))
		return false
	var gt := tree.global_tile_for(target)
	var kind := generator.material_at(gt.x, gt.y)
	if kind == WorldGenerator.SoilKind.AIR:
		EventBus.toast.emit(tr("MSG_ROOT_BLOCKED"))
		return false
	var cost := GrowthCost.for_tile(generator, gt.x, gt.y)
	if tree.glucose < cost:
		EventBus.toast.emit(tr("MSG_NOT_ENOUGH_GLUCOSE"))
		return false
	var grown := tree.grow_root_from(tip, true)
	if grown == null:
		EventBus.toast.emit(tr("MSG_ROOT_BLOCKED"))
		return false
	tree.glucose -= cost
	EventBus.tree_grew.emit(tree, "root")
	EventBus.root_grown.emit(tree, gt, cost)
	EventBus.toast.emit(tr("MSG_GROW_ROOT_COST") % [GrowthCost.material_name(kind), cost])
	return true


## PHASE-1-kompatibler Einstieg: Klickhoehe entscheidet Wurzel oder Blatt.
func manual_growth(tree: BaseTree, pos: Vector2) -> bool:
	if tree == null:
		return false
	if pos.y >= tree.global_position.y:
		return manual_root_growth(tree, tree.deepest_tip())
	var cost: float = tree.species.growth_cost
	if not tree.can_grow("leaf"):
		return false
	if tree.glucose < cost:
		EventBus.toast.emit(tr("MSG_NOT_ENOUGH_GLUCOSE"))
		return false
	if not tree.grow_part("leaf"):
		return false
	tree.glucose -= cost
	EventBus.tree_grew.emit(tree, "leaf")
	EventBus.toast.emit(tr("MSG_GROW_LEAF"))
	return true


# --------------------------------------------------------------------------- #
# Save/Load & Debug-Hooks
# --------------------------------------------------------------------------- #
func get_seed_count() -> int:
	return seed_count


func set_seed_count(value: int) -> void:
	seed_count = maxi(value, 0)
	EventBus.inventory_changed.emit(seed_count)


func clear_trees() -> void:
	for tree in get_tree().get_nodes_in_group("trees"):
		tree.remove_from_group("trees")
		tree.get_parent().remove_child(tree)
		tree.free()
	selected_tree = null


## Debug-Hooks pflanzen bewusst immer am Welt-Ursprung: reproduzierbar auch
## dann, wenn die Maus-im-Rand-Kamera im Headless-Modus leicht nach links
## driftet. Normale Spieler-Klicks bleiben natuerlich frei positionierbar.
func debug_plant_twice() -> void:
	var x := 0.0
	var pos := Vector2(x, generator.height_at(x) + 8.0)
	plant_seed_at(pos, true)
	plant_seed_at(pos, true)


## 1. Eichel MIT Vogel-Animation (Screenshot-Preset / manuelles Demo).
func debug_first_seed() -> void:
	plant_seed_at(Vector2(0.0, generator.height_at(0.0) + 8.0), false)


## PHASE 2: Wurzel bis zu den Reservoiren wachsen lassen (Screenshot/Smoke).
func debug_grow_roots(count: int) -> void:
	var tree := selected_tree
	if tree == null:
		return
	for _i in count:
		if tree.grow_root_from(tree.deepest_tip(), true) == null:
			break


## PHASE 2: Ghost-Preview ohne echte Mausbewegung sichtbar machen.
func debug_show_ghost() -> void:
	if ghost == null or selected_tree == null:
		return
	var tree := selected_tree
	var tip := tree.deepest_tip()
	var target := tree.propose_next_tile(tip)
	if target == BaseTree.INVALID_TILE:
		return
	var gt := tree.global_tile_for(target)
	var kind := generator.material_at(gt.x, gt.y)
	var cost := GrowthCost.for_tile(generator, gt.x, gt.y)
	var affordable := tree.glucose >= cost
	var material := GrowthCost.material_name(kind)
	ghost.show_at(Vector2(float(gt.x * WorldGenerator.TILE_SIZE),
		float(gt.y * WorldGenerator.TILE_SIZE)), cost, affordable, material)
	EventBus.ghost_preview.emit(gt, cost, affordable, material)


## PHASE 2: alle Reservoirs im Startbereich austrocknen (Screenshot).
func debug_drain_reservoirs() -> void:
	if world_state == null:
		return
	var top := generator.surface_tile_y_at(0.0)
	for gx in range(-10, 11):
		for ty in range(top, top + 40):
			if generator.reservoir_at(gx, ty):
				world_state.debug_drain(gx, ty)
