class_name TimeManager
extends Node
## PHASE 1: Platzhalter fuer das HUD (Jahr / Jahreszeit).
## PHASE 3 implementiert 15-20 Min/Jahr, Jahreszeiten, Zeitspulen x1/x3/x10
## und Pause. Es gibt WEDER Tag/Nacht noch Zeitfortschritt in PHASE 1.

var year: int = 1
var season: int = 0  # 0 = Fruehling


func get_label() -> String:
	return "%s %d · %s" % [tr("HUD_YEAR"), year, tr("SEASON_SPRING")]
