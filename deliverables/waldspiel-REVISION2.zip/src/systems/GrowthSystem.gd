class_name GrowthSystem
extends Node
## PHASE 1: Fotosynthese + Glucose-Verteilung.
## PHASE 2: AUTO zahlt fuer Wurzeln die BODENHÄRTE des Ziel-Tiles
## (GrowthCost), fuer Blaetter/Stamm den art-spezifischen Basispreis.
## MANUELL: kein Auto-Kauf, der Spieler klickt selbst
## (InteractionController.manual_root_growth / manual_growth).

@export var auto_growth_enabled: bool = true
const DURST_SCHWELLE := 40.0
const DEBUG_STEP := 0.1

var generator: WorldGenerator


func setup(p_generator: WorldGenerator) -> void:
	generator = p_generator


func _process(delta: float) -> void:
	tick(delta)


func tick(delta: float) -> void:
	for tree in get_tree().get_nodes_in_group("trees"):
		tree.photosynthesize(delta)
		if not Global.auto_mode or not auto_growth_enabled:
			continue
		# Prioritaet: Wurzeln bei Durst, sonst Blaetter (Stamm als Fallback).
		var part := "root" if tree.water < DURST_SCHWELLE else "leaf"
		if not tree.can_grow(part):
			part = "trunk"
		var cost: float = tree.species.growth_cost
		if part == "root":
			cost = GrowthCost.for_root(tree, generator)
			if cost < 0.0:
				part = "leaf"
				cost = tree.species.growth_cost
		if tree.glucose < cost:
			continue
		if tree.grow_part(part):
			tree.glucose -= cost
			EventBus.tree_grew.emit(tree, part)


## Deterministische Zeit-Simulation fuer Screenshots / Smoke-Tests.
func debug_advance(seconds: float) -> void:
	var steps := int(seconds / DEBUG_STEP)
	for _i in steps:
		tick(DEBUG_STEP)
