class_name BirdEvent
extends Node2D
## Scripted Tutorial-Event (Punkt 4.1): Vogel fliegt rein, pickt die erste
## Eichel und fliegt wieder weg. Reine Tween-Animation, keine Spiellogik hier.

const BIRD_PATH := "res://assets/placeholders/bird.png"


func spawn_bird(at: Vector2, instant: bool = false) -> void:
	var sprite := Sprite2D.new()
	sprite.name = "Vogel"
	sprite.texture = load(BIRD_PATH)
	sprite.centered = false
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.z_index = 50
	sprite.position = at + Vector2(700.0, -220.0)
	add_child(sprite)

	if instant:
		sprite.queue_free()
		return

	var tw := create_tween()
	tw.tween_property(sprite, "position", at + Vector2(-8.0, -22.0), 0.85) \
		.set_trans(Tween.TRANS_SINE)
	tw.tween_callback(_peck.bind(sprite))
	tw.tween_interval(0.30)
	tw.tween_property(sprite, "position", at + Vector2(-780.0, -280.0), 1.05) \
		.set_trans(Tween.TRANS_SINE)
	tw.tween_callback(sprite.queue_free)


func _peck(sprite: Sprite2D) -> void:
	sprite.flip_h = true
	sprite.position.y += 10.0
