# Wald-Regeneration — PHASE 2 + REVISION 2

> 2D-Seitenansicht (Himmel **und** Bodenquerschnitt) · Godot **4.7.2 stable** · GDScript · Forward+ / Vulkan
> Inspiriert von Mycelium / Mycelarium. Nach dem Waldbrand: 2 Eicheln, ein hungriger Vogel, ein Keimling mit wachsender Pfahlwurzel.

**Status:** PHASE 0 ✅ · PHASE 1 ✅ · PHASE 2 ✅ · REVISION 1 ✅ · **REVISION 2 ✅ (3 Korrekturen, getestet)** · **PHASE 3 wurde nicht begonnen.**

**Am Ende jeder abgeschlossenen Runde gibt es zusätzlich eine komplette ZIP** → `waldspiel-REVISION2.zip` (ersetzt `waldspiel-REVISION1.zip`).

---

## Starten

1. Godot 4.7.2 stable öffnen → `project.godot` importieren (oder die ZIP entpacken und `GODOT-IMPORT.txt` folgen).
2. **F5**. Das Spiel startet **direkt im Vollbild** und skaliert sich auf die Monitorfläche – keine grauen Ränder mehr. **F11** schaltet Vollbild/Fenster um; `--windowed` ist ein Start-Argument für Tests.
3. Der **Welt-Seed wird bei jedem Neustart neu gewürfelt**. Für eine reproduzierbare Welt: `--seed=20261105` oder **Laden** (Seed steht im Savegame).

## Steuerung

| Eingabe | Wirkung |
|---|---|
| **Linksklick auf das Eichel-Icon (HUD) oder freien Boden** | Eichel **aufnehmen**: sie schwebt ab jetzt an der Maus |
| **Linksklick, während die Eichel schwebt** | Eichel **überall auf der Oberfläche platzieren** (X-Position der Maus, sanft auf die Geländelinie gesetzt) |
| Rechtsklick / `Esc` beim Tragen | Eichel zurück ins Inventar legen (kein Verbrauch, kein Vogel) |
| MANUELL: Linksklick auf ein Wurzel-Segment | Wurzel wächst in Erd-Richtung; Kosten nach Boden (Ghost-Preview zeigt Ziel + Preis) |
| MANUELL: Linksklick auf Baumkrone | Blatt wachsen (10 Glucose) |
| AUTO | Baum verteilt Glucose selbst (Wurzeln bei Durst, sonst Blätter) |
| Rechtsklick (ohne getragene Eichel) | Info (Baumwerte oder Bodenmaterial / Tiefe / Wurzel-Kosten / Seed) |
| `W A S D` / Maus am Rand | Kamera schwenken |
| Mausrad | Zoom `0.5x … 2.0x`, weich interpoliert |
| `R` | Regen sofort auslösen (Dev-Hook; echtes Intervall 2–5 Min) |
| `F11` | Vollbild an/aus |
| HUD | AUTO/MANUELL, DE/EN, Speichern, Laden |

**Vogel-Timing:** Die **erste platzierte** Eichel wird weiterhin vom Vogel geklaut – aber **erst nach dem Platzierungsversuch**, nicht schon beim Aufnehmen. Danach keimt die zweite Eichel.

Skilltree-Button = deaktivierter Platzhalter (PHASE 4). Zeit „Jahr 1 · Frühling" = Platzhalter (PHASE 3). Kein Tag/Nacht.

## REVISION 2 – die drei Korrekturen

1. **Schönere Kanten für ALLE Strukturen.** Das 4px-Prinzip der Oberfläche (`TerrainSurface.gd`) gilt jetzt auch für Höhlen, Wasserreservoirs und Erdschichtgrenzen: neues `TerrainContours.gd` übermalt die harten 16px-Struktur-Tiles mit dem echten Boden-Atlas, zeichnet weiche Schichtbänder mit Rim/Lichtsaum (`layer_edge_y()`, folgt der Hügellinie) und rendert Höhlen/Wasser als **bilinear interpolierte Isolinie** in 4px-Schritten mit `edge_wobble_at()`. Nachbar-Tiles werden direkt beim Generator abgefragt → keine Lücken an Chunk-Grenzen; senkrechte Rims an Chunk-Kanten werden unterdrückt. Kollision/Logik/Save bleiben 16px.
2. **Höhlen ~50 % seltener.** `WorldGenerator.cave_area_scale = 0.5` skaliert die Radien der bestehenden Blob-Familien mit `sqrt(0.5)`, **nicht** die Zellenzahl. Dadurch bleibt die Verteilung seed-deterministisch und organisch, ohne dass einzelne Seeds komplett leer werden. Gemessen über 6 Seeds: **51–55 %** der REV1-Höhlenfläche (z. B. 771 statt 1403 Tiles bei Seed 20261105). `set_cave_area_scale()` bleibt für Tests/Smokes verfügbar.
3. **Realistisches Wasser.** `WorldState.gd` fasst alle 4-fach verbundenen Wasser-Tiles zu **einem Becken mit einem gemeinsamen Volumen** zusammen (90 Einheiten/Tile). `consume()` entnimmt dem ganzen Becken, der Pegel sinkt **zeilenweise von oben nach unten** (`waterline_px()`), passive Versickerung und Regen-Auffüllen wirken auf das Gesamtvolumen. Eine 1-Tile-Dilatation im Generator schließt Löcher und verbindet eng benachbarte Linsen, damit das Wasser „zusammenhängt". `TerrainContours` zeigt oberhalb des Pegels hellen leeren Boden, darunter Blau, mit einer hellen Wasserspiegel-Linie. Save-Format **v3** speichert Becken-Volumina; v2/v1-Saves bleiben lesbar.

## REVISION 1 – die vier Korrekturen (weiterhin gültig)

1. **Vollbild füllt den Monitor.** `window/size/mode=3`, `aspect="expand"`, `Main._fit_display()` setzt `content_scale_factor = min(Breite/1920, Höhe/1080)`. Verifiziert mit Xvfb-Root-Captures bei 2560×1440 und 3440×1440.
2. **Organischere Untergrund-Strukturen.** `WorldGenerator._blob_field()` legt pro Zelle 1–3 rotierte Ellipsen mit Jitter über Zellgrenzen hinaus an; `FastNoiseLite` verformt den Rand. Drei überlagerte Familien, kein Raster, kein 1-Tile-Rauschen.
3. **Fließende Oberfläche.** `height_smooth_at()` + `TerrainSurface.gd` in 4px-Schritten (max. Sprung 4 px statt 16 px); oberste TileMapLayer-Zeile wird durch das Profil ersetzt.
4. **Eichel-Schwebe & freie Platzierung.** `pick_up_acorn()` → Sprite auf `CarryLayer` + Vorschau → `_place_carried()` → **danach** `plant_seed_at()` mit Vogel-Event. Abbruch per Rechtsklick/`Esc`, Save/Load erhält die getragene Eichel.

## Was PHASE 2 simuliert (unverändert gültig)

- **Echte Wurzeln:** `Tree -> Roots -> RootSegment -> RootTip`, 16px-Raster, max. 32 Segmente. Eiche = Pfahlwurzel + Herzwurzelsystem.
- **Bodenhärte:** `GrowthCost` – Asche 8, Humus 9, **Mutterboden 10**, Lehm 13, Fels 25, Stein 30, Reservoir 15, Höhle 4 Glucose. AUTO und MANUELL zahlen identisch.
- **Ghost-Preview:** grüner Rahmen + transparentes Wurzel-Sprite + Preis; rot bei zu wenig Glucose.
- **Wasserreservoirs:** seit REVISION 2 ein Becken = ein Volumen; `remaining_at()` rechnet für HUD/P2-Smoke auf die alte Pro-Tile-Skala um.
- **Speichern v3:** Wurzel-Segmente + Becken-Volumina + getragene Eichel; liest v2 und v1 weiter.

## Ordnerstruktur

```
waldspiel/
├── project.godot                    # Godot 4.7.2, Forward+, Fullscreen, Nearest
├── GODOT-IMPORT.txt                 # Import-Anleitung (liegt auch in der ZIP)
├── DECISIONS.md                     # alle Annahmen (PHASE 0/1/2 + REVISION 1/2)
├── README.md
├── PHASE0/1/2-ERGEBNIS.md + .html   # historische Ergebnisberichte
├── REVISION1-ERGEBNIS.md + .html    # historischer Bericht
├── REVISION2-ERGEBNIS.md + .html    # Bericht DIESER Korrekturrunde
├── tools/
│   ├── generate_placeholders.py     # erzeugt alle 18 PNGs neu (17 Atlas-Slots)
│   ├── build_phase0/1/2_report.py, build_revision1_report.py
│   ├── build_revision2_report.py    # Bericht mit eingebetteten Screenshots
│   └── build_zip.py                 # vollständige Godot-ZIP
├── assets/placeholders/             # Boden-Atlas, Sprites, Icons, Himmel/Berge
├── data/localization.csv            # Key, DE, EN (alle Phasen)
├── data/species/oak.tres
├── src/
│   ├── Main.gd / Main.tscn           # _fit_display(), F11, CarryLayer, Presets
│   ├── autoload/                    # Global (Zufallsseed), EventBus
│   ├── world/                       # WorldGenerator, TerrainSurface, TerrainContours,
│   │                                # TerrainAtlas, Chunk, ChunkManager, WorldState
│   ├── camera/, background/, plants/, systems/, ui/
├── tests/                           # Phase0/1/2Smoke.gd + Revision1/2Smoke.gd
└── screenshots/                     # phase0/1/2_*, rev1_*, rev2_*.png
```

## Tests

```bash
godot --headless --path . --import
godot --headless --path . --quit-after 180        # F5-Ersatz
godot --headless --path . -- --phase0-smoke       # Regression: OK
godot --headless --path . -- --phase1-smoke       # Regression: OK
godot --headless --path . -- --phase2-smoke       # Regression: OK
godot --headless --path . -- --rev1-smoke         # Regression: OK
godot --headless --path . -- --rev2-smoke         # REVISION 2: 26 Checks, OK
```

`--rev2-smoke` prüft u. a. `cave_area_scale=0.5` (≈50 % Höhlenfläche über mehrere Seeds), organische Blob-Kanten, 4px-Konturen und Erdschicht-Rims, **ein** zusammenhängendes Becken, Entnahme am unteren Tile senkt den Pegel des ganzen Beckens, trockene Tiles oberhalb / nasse unterhalb, passive Versickerung, Regen-Auffüllung, `SLOT_DRY_WATER`, v3-Save/Load (35 % → 35 %), 5 Chunks, Nearest + Forward+, DE/EN und alle P0–P2/REV1-Regressionen. Erwartung: `[SMOKE] Ergebnis: OK`, **keine roten Fehler**.

Reproduzierbare Screenshots (Godot + Xvfb):

```bash
--seed=20261105 --rev2-shot-edges        # weiche Erdschicht-/Höhlen-/Wasserkanten
--seed=20261105 --rev2-shot-water        # Becken bei 45 %, Pegel von oben nach unten
--seed=20261105 --rev2-shot-water-low    # Becken bei 18 %
--seed=20261105 --phase2-shot-caves      # Höhlendichte (~50 % seltener)
--seed=20261105 --rev1-shot-surface      # fließende Oberfläche (Regression)
--windowed                               # Tests trotz Fullscreen-Default
```

## ZIP (vollständig, Godot-importierbar)

```bash
python3 tools/build_zip.py REVISION2   # -> /home/user/waldspiel-REVISION2.zip
```

`project.godot` liegt im **ZIP-Root**, `.godot/`-Cache und generierte `.translation` sind ausgeschlossen; alle Quellen, Assets, `.import`/`.uid`, Tests, Berichte und Screenshots sind drin. CRC-Test ist Teil des Skripts.

## Berichte / Platzhalter neu erzeugen

```bash
python3 tools/generate_placeholders.py
python3 tools/build_revision2_report.py
python3 tools/build_zip.py REVISION2
```

Details und Begründungen: **[DECISIONS.md](DECISIONS.md)** · Aktuelles Ergebnis: **[REVISION2-ERGEBNIS.md](REVISION2-ERGEBNIS.md)** / **[REVISION2-ERGEBNIS.html](REVISION2-ERGEBNIS.html)**.
